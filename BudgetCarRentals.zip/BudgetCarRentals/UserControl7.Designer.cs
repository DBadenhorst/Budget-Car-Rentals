﻿namespace BudgetCarRentals
{
    partial class ucAddMakeModel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAddMakeModel_EnterMake = new System.Windows.Forms.Label();
            this.lblAddMakeModel_SelectMake = new System.Windows.Forms.Label();
            this.txtAddMakeModel_MakeDetail = new System.Windows.Forms.TextBox();
            this.cbAddMakeModel_Make = new System.Windows.Forms.ComboBox();
            this.lblAddMakeModel_Model = new System.Windows.Forms.Label();
            this.txtAddMakeModel_Model = new System.Windows.Forms.TextBox();
            this.btnAddMakeModel_AddMake = new System.Windows.Forms.Button();
            this.btnAddMakeModel_AddModel = new System.Windows.Forms.Button();
            this.lblAddMakeModel_TitleModel = new System.Windows.Forms.Label();
            this.lblAddMakeModel_TitleMake = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblAddMakeModel_EnterMake
            // 
            this.lblAddMakeModel_EnterMake.AutoSize = true;
            this.lblAddMakeModel_EnterMake.Location = new System.Drawing.Point(4, 74);
            this.lblAddMakeModel_EnterMake.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAddMakeModel_EnterMake.Name = "lblAddMakeModel_EnterMake";
            this.lblAddMakeModel_EnterMake.Size = new System.Drawing.Size(67, 25);
            this.lblAddMakeModel_EnterMake.TabIndex = 2;
            this.lblAddMakeModel_EnterMake.Text = "Make:";
            // 
            // lblAddMakeModel_SelectMake
            // 
            this.lblAddMakeModel_SelectMake.AutoSize = true;
            this.lblAddMakeModel_SelectMake.Location = new System.Drawing.Point(-2, 74);
            this.lblAddMakeModel_SelectMake.Name = "lblAddMakeModel_SelectMake";
            this.lblAddMakeModel_SelectMake.Size = new System.Drawing.Size(127, 25);
            this.lblAddMakeModel_SelectMake.TabIndex = 3;
            this.lblAddMakeModel_SelectMake.Text = "Select Make:";
            // 
            // txtAddMakeModel_MakeDetail
            // 
            this.txtAddMakeModel_MakeDetail.Location = new System.Drawing.Point(-1, 102);
            this.txtAddMakeModel_MakeDetail.Name = "txtAddMakeModel_MakeDetail";
            this.txtAddMakeModel_MakeDetail.Size = new System.Drawing.Size(281, 30);
            this.txtAddMakeModel_MakeDetail.TabIndex = 4;
            // 
            // cbAddMakeModel_Make
            // 
            this.cbAddMakeModel_Make.FormattingEnabled = true;
            this.cbAddMakeModel_Make.Location = new System.Drawing.Point(3, 102);
            this.cbAddMakeModel_Make.Name = "cbAddMakeModel_Make";
            this.cbAddMakeModel_Make.Size = new System.Drawing.Size(281, 33);
            this.cbAddMakeModel_Make.TabIndex = 5;
            this.cbAddMakeModel_Make.SelectedIndexChanged += new System.EventHandler(this.cbAddMakeModel_Make_SelectedIndexChanged);
            // 
            // lblAddMakeModel_Model
            // 
            this.lblAddMakeModel_Model.AutoSize = true;
            this.lblAddMakeModel_Model.Location = new System.Drawing.Point(-2, 173);
            this.lblAddMakeModel_Model.Name = "lblAddMakeModel_Model";
            this.lblAddMakeModel_Model.Size = new System.Drawing.Size(72, 25);
            this.lblAddMakeModel_Model.TabIndex = 6;
            this.lblAddMakeModel_Model.Text = "Model:";
            // 
            // txtAddMakeModel_Model
            // 
            this.txtAddMakeModel_Model.Location = new System.Drawing.Point(3, 201);
            this.txtAddMakeModel_Model.Name = "txtAddMakeModel_Model";
            this.txtAddMakeModel_Model.Size = new System.Drawing.Size(281, 30);
            this.txtAddMakeModel_Model.TabIndex = 7;
            this.txtAddMakeModel_Model.TextChanged += new System.EventHandler(this.txtAddMakeModel_Model_TextChanged);
            // 
            // btnAddMakeModel_AddMake
            // 
            this.btnAddMakeModel_AddMake.BackColor = System.Drawing.Color.DimGray;
            this.btnAddMakeModel_AddMake.ForeColor = System.Drawing.Color.Black;
            this.btnAddMakeModel_AddMake.Location = new System.Drawing.Point(401, 341);
            this.btnAddMakeModel_AddMake.Name = "btnAddMakeModel_AddMake";
            this.btnAddMakeModel_AddMake.Size = new System.Drawing.Size(132, 51);
            this.btnAddMakeModel_AddMake.TabIndex = 8;
            this.btnAddMakeModel_AddMake.Text = "Add";
            this.btnAddMakeModel_AddMake.UseVisualStyleBackColor = false;
            this.btnAddMakeModel_AddMake.Click += new System.EventHandler(this.btnAddMakeModel_AddMake_Click);
            // 
            // btnAddMakeModel_AddModel
            // 
            this.btnAddMakeModel_AddModel.BackColor = System.Drawing.Color.DimGray;
            this.btnAddMakeModel_AddModel.ForeColor = System.Drawing.Color.Black;
            this.btnAddMakeModel_AddModel.Location = new System.Drawing.Point(401, 341);
            this.btnAddMakeModel_AddModel.Name = "btnAddMakeModel_AddModel";
            this.btnAddMakeModel_AddModel.Size = new System.Drawing.Size(132, 51);
            this.btnAddMakeModel_AddModel.TabIndex = 9;
            this.btnAddMakeModel_AddModel.Text = "Add";
            this.btnAddMakeModel_AddModel.UseVisualStyleBackColor = false;
            this.btnAddMakeModel_AddModel.Click += new System.EventHandler(this.btnAddMakeModel_AddModel_Click);
            // 
            // lblAddMakeModel_TitleModel
            // 
            this.lblAddMakeModel_TitleModel.AutoSize = true;
            this.lblAddMakeModel_TitleModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddMakeModel_TitleModel.ForeColor = System.Drawing.Color.White;
            this.lblAddMakeModel_TitleModel.Location = new System.Drawing.Point(4, 0);
            this.lblAddMakeModel_TitleModel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAddMakeModel_TitleModel.Name = "lblAddMakeModel_TitleModel";
            this.lblAddMakeModel_TitleModel.Size = new System.Drawing.Size(123, 25);
            this.lblAddMakeModel_TitleModel.TabIndex = 1;
            this.lblAddMakeModel_TitleModel.Text = "Add Model:";
            // 
            // lblAddMakeModel_TitleMake
            // 
            this.lblAddMakeModel_TitleMake.AutoSize = true;
            this.lblAddMakeModel_TitleMake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddMakeModel_TitleMake.ForeColor = System.Drawing.Color.White;
            this.lblAddMakeModel_TitleMake.Location = new System.Drawing.Point(4, 0);
            this.lblAddMakeModel_TitleMake.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAddMakeModel_TitleMake.Name = "lblAddMakeModel_TitleMake";
            this.lblAddMakeModel_TitleMake.Size = new System.Drawing.Size(117, 25);
            this.lblAddMakeModel_TitleMake.TabIndex = 0;
            this.lblAddMakeModel_TitleMake.Text = "Add Make:";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.lblAddMakeModel_TitleModel);
            this.panel2.Controls.Add(this.lblAddMakeModel_SelectMake);
            this.panel2.Controls.Add(this.btnAddMakeModel_AddModel);
            this.panel2.Controls.Add(this.cbAddMakeModel_Make);
            this.panel2.Controls.Add(this.lblAddMakeModel_Model);
            this.panel2.Controls.Add(this.txtAddMakeModel_Model);
            this.panel2.Location = new System.Drawing.Point(643, 63);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(544, 397);
            this.panel2.TabIndex = 11;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnAddMakeModel_AddMake);
            this.panel1.Controls.Add(this.lblAddMakeModel_TitleMake);
            this.panel1.Controls.Add(this.txtAddMakeModel_MakeDetail);
            this.panel1.Controls.Add(this.lblAddMakeModel_EnterMake);
            this.panel1.Location = new System.Drawing.Point(89, 63);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(534, 397);
            this.panel1.TabIndex = 12;
            // 
            // ucAddMakeModel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "ucAddMakeModel";
            this.Size = new System.Drawing.Size(1618, 598);
            this.Load += new System.EventHandler(this.ucAddMakeModel_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lblAddMakeModel_EnterMake;
        private System.Windows.Forms.Label lblAddMakeModel_SelectMake;
        private System.Windows.Forms.TextBox txtAddMakeModel_MakeDetail;
        private System.Windows.Forms.ComboBox cbAddMakeModel_Make;
        private System.Windows.Forms.Label lblAddMakeModel_Model;
        private System.Windows.Forms.TextBox txtAddMakeModel_Model;
        private System.Windows.Forms.Button btnAddMakeModel_AddMake;
        private System.Windows.Forms.Button btnAddMakeModel_AddModel;
        private System.Windows.Forms.Label lblAddMakeModel_TitleModel;
        private System.Windows.Forms.Label lblAddMakeModel_TitleMake;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
    }
}
