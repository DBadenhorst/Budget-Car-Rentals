﻿namespace BudgetCarRentals
{
    partial class ucAddClient
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAddClient_Name = new System.Windows.Forms.Label();
            this.lblAddClient_Surname = new System.Windows.Forms.Label();
            this.lblAddClient_CellNumber = new System.Windows.Forms.Label();
            this.lblAddClient_LicenseNumber = new System.Windows.Forms.Label();
            this.txtAddClient_Name = new System.Windows.Forms.TextBox();
            this.txtAddClient_Surname = new System.Windows.Forms.TextBox();
            this.txtAddClient_CellNumber = new System.Windows.Forms.TextBox();
            this.txtAddClient_LicenseNumber = new System.Windows.Forms.TextBox();
            this.btnAddClient_Add = new System.Windows.Forms.Button();
            this.lblAddClient_Title = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblAddClient_Name
            // 
            this.lblAddClient_Name.AutoSize = true;
            this.lblAddClient_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddClient_Name.ForeColor = System.Drawing.Color.White;
            this.lblAddClient_Name.Location = new System.Drawing.Point(399, 142);
            this.lblAddClient_Name.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAddClient_Name.Name = "lblAddClient_Name";
            this.lblAddClient_Name.Size = new System.Drawing.Size(55, 20);
            this.lblAddClient_Name.TabIndex = 0;
            this.lblAddClient_Name.Text = "Name:";
            // 
            // lblAddClient_Surname
            // 
            this.lblAddClient_Surname.AutoSize = true;
            this.lblAddClient_Surname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddClient_Surname.ForeColor = System.Drawing.Color.White;
            this.lblAddClient_Surname.Location = new System.Drawing.Point(659, 142);
            this.lblAddClient_Surname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAddClient_Surname.Name = "lblAddClient_Surname";
            this.lblAddClient_Surname.Size = new System.Drawing.Size(78, 20);
            this.lblAddClient_Surname.TabIndex = 1;
            this.lblAddClient_Surname.Text = "Surname:";
            // 
            // lblAddClient_CellNumber
            // 
            this.lblAddClient_CellNumber.AutoSize = true;
            this.lblAddClient_CellNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddClient_CellNumber.ForeColor = System.Drawing.Color.White;
            this.lblAddClient_CellNumber.Location = new System.Drawing.Point(399, 244);
            this.lblAddClient_CellNumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAddClient_CellNumber.Name = "lblAddClient_CellNumber";
            this.lblAddClient_CellNumber.Size = new System.Drawing.Size(99, 20);
            this.lblAddClient_CellNumber.TabIndex = 2;
            this.lblAddClient_CellNumber.Text = "Cell Number:";
            // 
            // lblAddClient_LicenseNumber
            // 
            this.lblAddClient_LicenseNumber.AutoSize = true;
            this.lblAddClient_LicenseNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddClient_LicenseNumber.ForeColor = System.Drawing.Color.White;
            this.lblAddClient_LicenseNumber.Location = new System.Drawing.Point(659, 244);
            this.lblAddClient_LicenseNumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAddClient_LicenseNumber.Name = "lblAddClient_LicenseNumber";
            this.lblAddClient_LicenseNumber.Size = new System.Drawing.Size(128, 20);
            this.lblAddClient_LicenseNumber.TabIndex = 3;
            this.lblAddClient_LicenseNumber.Text = "License Number:";
            // 
            // txtAddClient_Name
            // 
            this.txtAddClient_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddClient_Name.Location = new System.Drawing.Point(403, 165);
            this.txtAddClient_Name.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtAddClient_Name.Name = "txtAddClient_Name";
            this.txtAddClient_Name.Size = new System.Drawing.Size(195, 26);
            this.txtAddClient_Name.TabIndex = 4;
            // 
            // txtAddClient_Surname
            // 
            this.txtAddClient_Surname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddClient_Surname.Location = new System.Drawing.Point(663, 165);
            this.txtAddClient_Surname.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtAddClient_Surname.Name = "txtAddClient_Surname";
            this.txtAddClient_Surname.Size = new System.Drawing.Size(195, 26);
            this.txtAddClient_Surname.TabIndex = 5;
            // 
            // txtAddClient_CellNumber
            // 
            this.txtAddClient_CellNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddClient_CellNumber.Location = new System.Drawing.Point(403, 266);
            this.txtAddClient_CellNumber.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtAddClient_CellNumber.Name = "txtAddClient_CellNumber";
            this.txtAddClient_CellNumber.Size = new System.Drawing.Size(195, 26);
            this.txtAddClient_CellNumber.TabIndex = 6;
            // 
            // txtAddClient_LicenseNumber
            // 
            this.txtAddClient_LicenseNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddClient_LicenseNumber.Location = new System.Drawing.Point(663, 266);
            this.txtAddClient_LicenseNumber.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtAddClient_LicenseNumber.Name = "txtAddClient_LicenseNumber";
            this.txtAddClient_LicenseNumber.Size = new System.Drawing.Size(195, 26);
            this.txtAddClient_LicenseNumber.TabIndex = 7;
            // 
            // btnAddClient_Add
            // 
            this.btnAddClient_Add.BackColor = System.Drawing.Color.DimGray;
            this.btnAddClient_Add.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddClient_Add.ForeColor = System.Drawing.Color.Black;
            this.btnAddClient_Add.Location = new System.Drawing.Point(1092, 433);
            this.btnAddClient_Add.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAddClient_Add.Name = "btnAddClient_Add";
            this.btnAddClient_Add.Size = new System.Drawing.Size(111, 41);
            this.btnAddClient_Add.TabIndex = 11;
            this.btnAddClient_Add.Text = "Add";
            this.btnAddClient_Add.UseVisualStyleBackColor = false;
            this.btnAddClient_Add.Click += new System.EventHandler(this.btnAddClient_Add_Click);
            // 
            // lblAddClient_Title
            // 
            this.lblAddClient_Title.AutoSize = true;
            this.lblAddClient_Title.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddClient_Title.ForeColor = System.Drawing.Color.White;
            this.lblAddClient_Title.Location = new System.Drawing.Point(10, 11);
            this.lblAddClient_Title.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAddClient_Title.Name = "lblAddClient_Title";
            this.lblAddClient_Title.Size = new System.Drawing.Size(92, 20);
            this.lblAddClient_Title.TabIndex = 12;
            this.lblAddClient_Title.Text = "Add Client";
            // 
            // ucAddClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.lblAddClient_Title);
            this.Controls.Add(this.btnAddClient_Add);
            this.Controls.Add(this.txtAddClient_LicenseNumber);
            this.Controls.Add(this.txtAddClient_CellNumber);
            this.Controls.Add(this.txtAddClient_Surname);
            this.Controls.Add(this.txtAddClient_Name);
            this.Controls.Add(this.lblAddClient_LicenseNumber);
            this.Controls.Add(this.lblAddClient_CellNumber);
            this.Controls.Add(this.lblAddClient_Surname);
            this.Controls.Add(this.lblAddClient_Name);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "ucAddClient";
            this.Size = new System.Drawing.Size(1214, 486);
            this.Load += new System.EventHandler(this.ucAddClient_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAddClient_Name;
        private System.Windows.Forms.Label lblAddClient_Surname;
        private System.Windows.Forms.Label lblAddClient_CellNumber;
        private System.Windows.Forms.Label lblAddClient_LicenseNumber;
        private System.Windows.Forms.TextBox txtAddClient_Name;
        private System.Windows.Forms.TextBox txtAddClient_Surname;
        private System.Windows.Forms.TextBox txtAddClient_CellNumber;
        private System.Windows.Forms.TextBox txtAddClient_LicenseNumber;
        private System.Windows.Forms.Button btnAddClient_Add;
        private System.Windows.Forms.Label lblAddClient_Title;
    }
}
