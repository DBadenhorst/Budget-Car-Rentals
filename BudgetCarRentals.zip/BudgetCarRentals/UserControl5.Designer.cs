﻿namespace BudgetCarRentals
{
    partial class ucAddVehicle
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAddVehicle_Title = new System.Windows.Forms.Label();
            this.lblAddVehicle_Make = new System.Windows.Forms.Label();
            this.lblAddVehicle_Model = new System.Windows.Forms.Label();
            this.lblAddVehicle_Registration = new System.Windows.Forms.Label();
            this.lblAddVehicle_Cost = new System.Windows.Forms.Label();
            this.cbAddVehicle_Make = new System.Windows.Forms.ComboBox();
            this.cbAddVehicle_Model = new System.Windows.Forms.ComboBox();
            this.txtAddVehicle_Registration = new System.Windows.Forms.TextBox();
            this.txtAddVehicle_Cost = new System.Windows.Forms.TextBox();
            this.btnAddVehicle_Add = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblAddVehicle_Title
            // 
            this.lblAddVehicle_Title.AutoSize = true;
            this.lblAddVehicle_Title.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddVehicle_Title.ForeColor = System.Drawing.Color.White;
            this.lblAddVehicle_Title.Location = new System.Drawing.Point(15, 13);
            this.lblAddVehicle_Title.Name = "lblAddVehicle_Title";
            this.lblAddVehicle_Title.Size = new System.Drawing.Size(105, 20);
            this.lblAddVehicle_Title.TabIndex = 0;
            this.lblAddVehicle_Title.Text = "Add Vehicle";
            // 
            // lblAddVehicle_Make
            // 
            this.lblAddVehicle_Make.AutoSize = true;
            this.lblAddVehicle_Make.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddVehicle_Make.ForeColor = System.Drawing.Color.White;
            this.lblAddVehicle_Make.Location = new System.Drawing.Point(538, 118);
            this.lblAddVehicle_Make.Name = "lblAddVehicle_Make";
            this.lblAddVehicle_Make.Size = new System.Drawing.Size(52, 20);
            this.lblAddVehicle_Make.TabIndex = 1;
            this.lblAddVehicle_Make.Text = "Make:";
            // 
            // lblAddVehicle_Model
            // 
            this.lblAddVehicle_Model.AutoSize = true;
            this.lblAddVehicle_Model.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddVehicle_Model.ForeColor = System.Drawing.Color.White;
            this.lblAddVehicle_Model.Location = new System.Drawing.Point(877, 118);
            this.lblAddVehicle_Model.Name = "lblAddVehicle_Model";
            this.lblAddVehicle_Model.Size = new System.Drawing.Size(56, 20);
            this.lblAddVehicle_Model.TabIndex = 2;
            this.lblAddVehicle_Model.Text = "Model:";
            // 
            // lblAddVehicle_Registration
            // 
            this.lblAddVehicle_Registration.AutoSize = true;
            this.lblAddVehicle_Registration.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddVehicle_Registration.ForeColor = System.Drawing.Color.White;
            this.lblAddVehicle_Registration.Location = new System.Drawing.Point(538, 259);
            this.lblAddVehicle_Registration.Name = "lblAddVehicle_Registration";
            this.lblAddVehicle_Registration.Size = new System.Drawing.Size(99, 20);
            this.lblAddVehicle_Registration.TabIndex = 3;
            this.lblAddVehicle_Registration.Text = "Registration:";
            // 
            // lblAddVehicle_Cost
            // 
            this.lblAddVehicle_Cost.AutoSize = true;
            this.lblAddVehicle_Cost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddVehicle_Cost.ForeColor = System.Drawing.Color.White;
            this.lblAddVehicle_Cost.Location = new System.Drawing.Point(877, 259);
            this.lblAddVehicle_Cost.Name = "lblAddVehicle_Cost";
            this.lblAddVehicle_Cost.Size = new System.Drawing.Size(46, 20);
            this.lblAddVehicle_Cost.TabIndex = 4;
            this.lblAddVehicle_Cost.Text = "Cost:";
            // 
            // cbAddVehicle_Make
            // 
            this.cbAddVehicle_Make.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbAddVehicle_Make.FormattingEnabled = true;
            this.cbAddVehicle_Make.Location = new System.Drawing.Point(543, 146);
            this.cbAddVehicle_Make.Name = "cbAddVehicle_Make";
            this.cbAddVehicle_Make.Size = new System.Drawing.Size(268, 28);
            this.cbAddVehicle_Make.TabIndex = 5;
            this.cbAddVehicle_Make.SelectedIndexChanged += new System.EventHandler(this.cbAddVehicle_Make_SelectedIndexChanged);
            // 
            // cbAddVehicle_Model
            // 
            this.cbAddVehicle_Model.Enabled = false;
            this.cbAddVehicle_Model.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbAddVehicle_Model.FormattingEnabled = true;
            this.cbAddVehicle_Model.Location = new System.Drawing.Point(882, 146);
            this.cbAddVehicle_Model.Name = "cbAddVehicle_Model";
            this.cbAddVehicle_Model.Size = new System.Drawing.Size(271, 28);
            this.cbAddVehicle_Model.TabIndex = 6;
            // 
            // txtAddVehicle_Registration
            // 
            this.txtAddVehicle_Registration.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddVehicle_Registration.Location = new System.Drawing.Point(543, 287);
            this.txtAddVehicle_Registration.Name = "txtAddVehicle_Registration";
            this.txtAddVehicle_Registration.Size = new System.Drawing.Size(268, 26);
            this.txtAddVehicle_Registration.TabIndex = 7;
            // 
            // txtAddVehicle_Cost
            // 
            this.txtAddVehicle_Cost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddVehicle_Cost.Location = new System.Drawing.Point(882, 287);
            this.txtAddVehicle_Cost.Name = "txtAddVehicle_Cost";
            this.txtAddVehicle_Cost.Size = new System.Drawing.Size(271, 26);
            this.txtAddVehicle_Cost.TabIndex = 8;
            // 
            // btnAddVehicle_Add
            // 
            this.btnAddVehicle_Add.BackColor = System.Drawing.Color.DimGray;
            this.btnAddVehicle_Add.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddVehicle_Add.Location = new System.Drawing.Point(1465, 525);
            this.btnAddVehicle_Add.Name = "btnAddVehicle_Add";
            this.btnAddVehicle_Add.Size = new System.Drawing.Size(123, 40);
            this.btnAddVehicle_Add.TabIndex = 9;
            this.btnAddVehicle_Add.Text = "Add";
            this.btnAddVehicle_Add.UseVisualStyleBackColor = false;
            this.btnAddVehicle_Add.Click += new System.EventHandler(this.btnAddVehicle_Add_Click);
            // 
            // ucAddVehicle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.btnAddVehicle_Add);
            this.Controls.Add(this.txtAddVehicle_Cost);
            this.Controls.Add(this.txtAddVehicle_Registration);
            this.Controls.Add(this.cbAddVehicle_Model);
            this.Controls.Add(this.cbAddVehicle_Make);
            this.Controls.Add(this.lblAddVehicle_Cost);
            this.Controls.Add(this.lblAddVehicle_Registration);
            this.Controls.Add(this.lblAddVehicle_Model);
            this.Controls.Add(this.lblAddVehicle_Make);
            this.Controls.Add(this.lblAddVehicle_Title);
            this.Name = "ucAddVehicle";
            this.Size = new System.Drawing.Size(1618, 598);
            this.Load += new System.EventHandler(this.ucAddVehicle_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAddVehicle_Title;
        private System.Windows.Forms.Label lblAddVehicle_Make;
        private System.Windows.Forms.Label lblAddVehicle_Model;
        private System.Windows.Forms.Label lblAddVehicle_Registration;
        private System.Windows.Forms.Label lblAddVehicle_Cost;
        private System.Windows.Forms.ComboBox cbAddVehicle_Make;
        private System.Windows.Forms.ComboBox cbAddVehicle_Model;
        private System.Windows.Forms.TextBox txtAddVehicle_Registration;
        private System.Windows.Forms.TextBox txtAddVehicle_Cost;
        private System.Windows.Forms.Button btnAddVehicle_Add;
    }
}
