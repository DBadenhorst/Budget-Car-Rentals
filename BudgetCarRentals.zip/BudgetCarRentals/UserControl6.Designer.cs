﻿namespace BudgetCarRentals
{
    partial class ucUpdateDeleteVehicle
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblUpdateDeleteVehicle_Title = new System.Windows.Forms.Label();
            this.lblUpdateDeleteVehicle_SelectVehicle = new System.Windows.Forms.Label();
            this.cbUpdateDeleteVehicle_SelectVehicle = new System.Windows.Forms.ComboBox();
            this.lblUpdateDeleteVehicle_Make = new System.Windows.Forms.Label();
            this.lblUpdateDeleteVehicle_Model = new System.Windows.Forms.Label();
            this.lblUpdateDeleteVehicle_Registration = new System.Windows.Forms.Label();
            this.lblUpdateDeleteVehicle_Cost = new System.Windows.Forms.Label();
            this.txtUpdateDeleteVehicle_Make = new System.Windows.Forms.TextBox();
            this.txtUpdateDeleteVehicle_Model = new System.Windows.Forms.TextBox();
            this.txtUpdateDeleteVehicle_Registration = new System.Windows.Forms.TextBox();
            this.txtUpdateDeleteVehicle_Cost = new System.Windows.Forms.TextBox();
            this.btnUpdateDeleteVehicle_Delete = new System.Windows.Forms.Button();
            this.btnUpdateDeleteVehicle_Update = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblUpdateDeleteVehicle_Title
            // 
            this.lblUpdateDeleteVehicle_Title.AutoSize = true;
            this.lblUpdateDeleteVehicle_Title.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateDeleteVehicle_Title.ForeColor = System.Drawing.Color.White;
            this.lblUpdateDeleteVehicle_Title.Location = new System.Drawing.Point(10, 10);
            this.lblUpdateDeleteVehicle_Title.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUpdateDeleteVehicle_Title.Name = "lblUpdateDeleteVehicle_Title";
            this.lblUpdateDeleteVehicle_Title.Size = new System.Drawing.Size(190, 20);
            this.lblUpdateDeleteVehicle_Title.TabIndex = 0;
            this.lblUpdateDeleteVehicle_Title.Text = "Update/Delete Vehicle";
            // 
            // lblUpdateDeleteVehicle_SelectVehicle
            // 
            this.lblUpdateDeleteVehicle_SelectVehicle.AutoSize = true;
            this.lblUpdateDeleteVehicle_SelectVehicle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateDeleteVehicle_SelectVehicle.ForeColor = System.Drawing.Color.White;
            this.lblUpdateDeleteVehicle_SelectVehicle.Location = new System.Drawing.Point(539, 85);
            this.lblUpdateDeleteVehicle_SelectVehicle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUpdateDeleteVehicle_SelectVehicle.Name = "lblUpdateDeleteVehicle_SelectVehicle";
            this.lblUpdateDeleteVehicle_SelectVehicle.Size = new System.Drawing.Size(114, 20);
            this.lblUpdateDeleteVehicle_SelectVehicle.TabIndex = 1;
            this.lblUpdateDeleteVehicle_SelectVehicle.Text = "Select Vehicle:";
            // 
            // cbUpdateDeleteVehicle_SelectVehicle
            // 
            this.cbUpdateDeleteVehicle_SelectVehicle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbUpdateDeleteVehicle_SelectVehicle.FormattingEnabled = true;
            this.cbUpdateDeleteVehicle_SelectVehicle.Location = new System.Drawing.Point(445, 117);
            this.cbUpdateDeleteVehicle_SelectVehicle.Margin = new System.Windows.Forms.Padding(2);
            this.cbUpdateDeleteVehicle_SelectVehicle.Name = "cbUpdateDeleteVehicle_SelectVehicle";
            this.cbUpdateDeleteVehicle_SelectVehicle.Size = new System.Drawing.Size(292, 28);
            this.cbUpdateDeleteVehicle_SelectVehicle.TabIndex = 2;
            this.cbUpdateDeleteVehicle_SelectVehicle.SelectedIndexChanged += new System.EventHandler(this.cbUpdateDeleteVehicle_SelectVehicle_SelectedIndexChanged);
            // 
            // lblUpdateDeleteVehicle_Make
            // 
            this.lblUpdateDeleteVehicle_Make.AutoSize = true;
            this.lblUpdateDeleteVehicle_Make.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateDeleteVehicle_Make.ForeColor = System.Drawing.Color.White;
            this.lblUpdateDeleteVehicle_Make.Location = new System.Drawing.Point(383, 169);
            this.lblUpdateDeleteVehicle_Make.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUpdateDeleteVehicle_Make.Name = "lblUpdateDeleteVehicle_Make";
            this.lblUpdateDeleteVehicle_Make.Size = new System.Drawing.Size(52, 20);
            this.lblUpdateDeleteVehicle_Make.TabIndex = 3;
            this.lblUpdateDeleteVehicle_Make.Text = "Make:";
            // 
            // lblUpdateDeleteVehicle_Model
            // 
            this.lblUpdateDeleteVehicle_Model.AutoSize = true;
            this.lblUpdateDeleteVehicle_Model.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateDeleteVehicle_Model.ForeColor = System.Drawing.Color.White;
            this.lblUpdateDeleteVehicle_Model.Location = new System.Drawing.Point(607, 169);
            this.lblUpdateDeleteVehicle_Model.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUpdateDeleteVehicle_Model.Name = "lblUpdateDeleteVehicle_Model";
            this.lblUpdateDeleteVehicle_Model.Size = new System.Drawing.Size(56, 20);
            this.lblUpdateDeleteVehicle_Model.TabIndex = 4;
            this.lblUpdateDeleteVehicle_Model.Text = "Model:";
            // 
            // lblUpdateDeleteVehicle_Registration
            // 
            this.lblUpdateDeleteVehicle_Registration.AutoSize = true;
            this.lblUpdateDeleteVehicle_Registration.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateDeleteVehicle_Registration.ForeColor = System.Drawing.Color.White;
            this.lblUpdateDeleteVehicle_Registration.Location = new System.Drawing.Point(383, 245);
            this.lblUpdateDeleteVehicle_Registration.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUpdateDeleteVehicle_Registration.Name = "lblUpdateDeleteVehicle_Registration";
            this.lblUpdateDeleteVehicle_Registration.Size = new System.Drawing.Size(99, 20);
            this.lblUpdateDeleteVehicle_Registration.TabIndex = 5;
            this.lblUpdateDeleteVehicle_Registration.Text = "Registration:";
            // 
            // lblUpdateDeleteVehicle_Cost
            // 
            this.lblUpdateDeleteVehicle_Cost.AutoSize = true;
            this.lblUpdateDeleteVehicle_Cost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateDeleteVehicle_Cost.ForeColor = System.Drawing.Color.White;
            this.lblUpdateDeleteVehicle_Cost.Location = new System.Drawing.Point(607, 245);
            this.lblUpdateDeleteVehicle_Cost.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUpdateDeleteVehicle_Cost.Name = "lblUpdateDeleteVehicle_Cost";
            this.lblUpdateDeleteVehicle_Cost.Size = new System.Drawing.Size(46, 20);
            this.lblUpdateDeleteVehicle_Cost.TabIndex = 6;
            this.lblUpdateDeleteVehicle_Cost.Text = "Cost:";
            // 
            // txtUpdateDeleteVehicle_Make
            // 
            this.txtUpdateDeleteVehicle_Make.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUpdateDeleteVehicle_Make.Location = new System.Drawing.Point(385, 192);
            this.txtUpdateDeleteVehicle_Make.Margin = new System.Windows.Forms.Padding(2);
            this.txtUpdateDeleteVehicle_Make.Name = "txtUpdateDeleteVehicle_Make";
            this.txtUpdateDeleteVehicle_Make.Size = new System.Drawing.Size(191, 26);
            this.txtUpdateDeleteVehicle_Make.TabIndex = 7;
            // 
            // txtUpdateDeleteVehicle_Model
            // 
            this.txtUpdateDeleteVehicle_Model.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUpdateDeleteVehicle_Model.Location = new System.Drawing.Point(610, 192);
            this.txtUpdateDeleteVehicle_Model.Margin = new System.Windows.Forms.Padding(2);
            this.txtUpdateDeleteVehicle_Model.Name = "txtUpdateDeleteVehicle_Model";
            this.txtUpdateDeleteVehicle_Model.Size = new System.Drawing.Size(191, 26);
            this.txtUpdateDeleteVehicle_Model.TabIndex = 8;
            // 
            // txtUpdateDeleteVehicle_Registration
            // 
            this.txtUpdateDeleteVehicle_Registration.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUpdateDeleteVehicle_Registration.Location = new System.Drawing.Point(385, 268);
            this.txtUpdateDeleteVehicle_Registration.Margin = new System.Windows.Forms.Padding(2);
            this.txtUpdateDeleteVehicle_Registration.Name = "txtUpdateDeleteVehicle_Registration";
            this.txtUpdateDeleteVehicle_Registration.Size = new System.Drawing.Size(191, 26);
            this.txtUpdateDeleteVehicle_Registration.TabIndex = 9;
            // 
            // txtUpdateDeleteVehicle_Cost
            // 
            this.txtUpdateDeleteVehicle_Cost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUpdateDeleteVehicle_Cost.Location = new System.Drawing.Point(610, 268);
            this.txtUpdateDeleteVehicle_Cost.Margin = new System.Windows.Forms.Padding(2);
            this.txtUpdateDeleteVehicle_Cost.Name = "txtUpdateDeleteVehicle_Cost";
            this.txtUpdateDeleteVehicle_Cost.Size = new System.Drawing.Size(191, 26);
            this.txtUpdateDeleteVehicle_Cost.TabIndex = 10;
            // 
            // btnUpdateDeleteVehicle_Delete
            // 
            this.btnUpdateDeleteVehicle_Delete.BackColor = System.Drawing.Color.DimGray;
            this.btnUpdateDeleteVehicle_Delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateDeleteVehicle_Delete.Location = new System.Drawing.Point(610, 346);
            this.btnUpdateDeleteVehicle_Delete.Margin = new System.Windows.Forms.Padding(2);
            this.btnUpdateDeleteVehicle_Delete.Name = "btnUpdateDeleteVehicle_Delete";
            this.btnUpdateDeleteVehicle_Delete.Size = new System.Drawing.Size(92, 32);
            this.btnUpdateDeleteVehicle_Delete.TabIndex = 11;
            this.btnUpdateDeleteVehicle_Delete.Text = "Delete";
            this.btnUpdateDeleteVehicle_Delete.UseVisualStyleBackColor = false;
            this.btnUpdateDeleteVehicle_Delete.Click += new System.EventHandler(this.btnUpdateDeleteVehicle_Delete_Click);
            // 
            // btnUpdateDeleteVehicle_Update
            // 
            this.btnUpdateDeleteVehicle_Update.BackColor = System.Drawing.Color.DimGray;
            this.btnUpdateDeleteVehicle_Update.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateDeleteVehicle_Update.Location = new System.Drawing.Point(482, 346);
            this.btnUpdateDeleteVehicle_Update.Margin = new System.Windows.Forms.Padding(2);
            this.btnUpdateDeleteVehicle_Update.Name = "btnUpdateDeleteVehicle_Update";
            this.btnUpdateDeleteVehicle_Update.Size = new System.Drawing.Size(92, 32);
            this.btnUpdateDeleteVehicle_Update.TabIndex = 12;
            this.btnUpdateDeleteVehicle_Update.Text = "Update";
            this.btnUpdateDeleteVehicle_Update.UseVisualStyleBackColor = false;
            this.btnUpdateDeleteVehicle_Update.Click += new System.EventHandler(this.btnUpdateDeleteVehicle_Update_Click);
            // 
            // ucUpdateDeleteVehicle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.btnUpdateDeleteVehicle_Update);
            this.Controls.Add(this.btnUpdateDeleteVehicle_Delete);
            this.Controls.Add(this.txtUpdateDeleteVehicle_Cost);
            this.Controls.Add(this.txtUpdateDeleteVehicle_Registration);
            this.Controls.Add(this.txtUpdateDeleteVehicle_Model);
            this.Controls.Add(this.txtUpdateDeleteVehicle_Make);
            this.Controls.Add(this.lblUpdateDeleteVehicle_Cost);
            this.Controls.Add(this.lblUpdateDeleteVehicle_Registration);
            this.Controls.Add(this.lblUpdateDeleteVehicle_Model);
            this.Controls.Add(this.lblUpdateDeleteVehicle_Make);
            this.Controls.Add(this.cbUpdateDeleteVehicle_SelectVehicle);
            this.Controls.Add(this.lblUpdateDeleteVehicle_SelectVehicle);
            this.Controls.Add(this.lblUpdateDeleteVehicle_Title);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ucUpdateDeleteVehicle";
            this.Size = new System.Drawing.Size(1214, 486);
            this.Load += new System.EventHandler(this.ucUpdateDeleteVehicle_Load);
            this.Enter += new System.EventHandler(this.ucUpdateDeleteVehicle_Enter);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblUpdateDeleteVehicle_Title;
        private System.Windows.Forms.Label lblUpdateDeleteVehicle_SelectVehicle;
        private System.Windows.Forms.ComboBox cbUpdateDeleteVehicle_SelectVehicle;
        private System.Windows.Forms.Label lblUpdateDeleteVehicle_Make;
        private System.Windows.Forms.Label lblUpdateDeleteVehicle_Model;
        private System.Windows.Forms.Label lblUpdateDeleteVehicle_Registration;
        private System.Windows.Forms.Label lblUpdateDeleteVehicle_Cost;
        private System.Windows.Forms.TextBox txtUpdateDeleteVehicle_Make;
        private System.Windows.Forms.TextBox txtUpdateDeleteVehicle_Model;
        private System.Windows.Forms.TextBox txtUpdateDeleteVehicle_Registration;
        private System.Windows.Forms.TextBox txtUpdateDeleteVehicle_Cost;
        private System.Windows.Forms.Button btnUpdateDeleteVehicle_Delete;
        private System.Windows.Forms.Button btnUpdateDeleteVehicle_Update;
    }
}
