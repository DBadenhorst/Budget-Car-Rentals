USE Budget_Car_Rental_Data
GO


CREATE TABLE MAKE(
Vehicle_Make_ID int IDENTITY(1,1) PRIMARY KEY,
Make_Description varchar(15)
);

CREATE TABLE CLIENT_INFORMATION(
Client_ID int IDENTITY(1,1) PRIMARY KEY,
Client_FName varchar(25),
Client_LName varchar(25),
Contact_No char(10),
Lisence_No char(12)
);

CREATE TABLE MODEL(
Vehicle_Model_id int IDENTITY(1,1) PRIMARY KEY,
Vehicle_Make_ID int FOREIGN KEY REFERENCES MAKE,
Model_Description varchar(50)
);

CREATE TABLE VEHICLE(
Vehicle_ID int IDENTITY(1,1) PRIMARY KEY,
Vehicle_Make_ID int FOREIGN KEY REFERENCES MAKE,
Vehicle_Model_id int FOREIGN KEY REFERENCES MODEL,
Vehicle_Status bit,
Registration char(8),
Cost smallmoney
);

CREATE TABLE RENTED_VEHICLE_TRANSACTIONS(
Rented_ID int IDENTITY(1,1) PRIMARY KEY,
Client_ID int FOREIGN KEY REFERENCES CLIENT_INFORMATION,
Vehicle_ID int FOREIGN KEY REFERENCES VEHICLE,
Rented_date date,
Returned_Date date,
Cost smallmoney
);