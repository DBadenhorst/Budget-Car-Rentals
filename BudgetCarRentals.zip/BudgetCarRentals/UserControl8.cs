﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace BudgetCarRentals
{
    public partial class ucUpdateDeleteMakeModel : UserControl
    {
        SqlConnection conn = new SqlConnection(@"Data Source=JEANDRE-PC;Initial Catalog=Budget_Car_Rental_Data;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        SqlCommand comm;
        SqlDataAdapter adapt;
        SqlDataReader reader;
        public ucUpdateDeleteMakeModel()
        {
            InitializeComponent();
        }

        private void populate()
        {
            
        }

        private void btnUpdateDeleteMakeModel_DeleteMake_Click(object sender, EventArgs e)
        {
            string make = cbUpdateDeleteMakeModel_MakeSelectMake.Text;
            if (make != "")
            {
                string message = "Are you sure you want to delete '" + cbUpdateDeleteMakeModel_MakeSelectMake.Text + "'?";
                string title = "WARNING!";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result = MessageBox.Show(message, title, buttons);
                if (result == DialogResult.Yes)
                {
                    conn.Open();

                    string sql = $"DELETE FROM Make WHERE Make_Description = '{cbUpdateDeleteMakeModel_MakeSelectMake.Text}'";
                    comm = new SqlCommand(sql, conn);   
                    comm.ExecuteNonQuery();

                    conn.Close();

                    MessageBox.Show(cbUpdateDeleteMakeModel_MakeSelectMake.Text + " was deleted successfully!");

                    txtUpdateDeleteMakeModel_MakeMake.Text = "";
                    cbUpdateDeleteMakeModel_MakeSelectMake.Text = "";
                    cbUpdateDeleteMakeModel_MakeSelectMake.Items.Clear();
                    cbUpdateDeleteMakeModel_ModelMake.Items.Clear();

                    conn.Open();
                    sql = "SELECT DISTINCT Make_Description FROM Make";
                    comm = new SqlCommand(sql, conn);
                    adapt = new SqlDataAdapter();
                    adapt.SelectCommand = comm;
                    reader = comm.ExecuteReader();

                    make = "";
                    while (reader.Read())
                    {
                        make = reader.GetString(0);
                        cbUpdateDeleteMakeModel_MakeSelectMake.Items.Add(make);
                        cbUpdateDeleteMakeModel_ModelMake.Items.Add(make);
                    }
                    reader.Close();
                    conn.Close();


                }
            }
            
            else
            {
                MessageBox.Show("Please select a make");
            }
        }

        private void btnUpdateDeleteMakeModel_UpdateModel_Click(object sender, EventArgs e)
        {
            if (cbUpdateDeleteMakeModel_ModelModel.Text != "")
            {
                int model_id = 0;
                int make_id = 0;
                string model = txtUpdateDeleteMakeModel_ModelModel.Text;

                conn.Open();
                string sql = $"SELECT Vehicle_Model_id, Vehicle_Make_id FROM Model WHERE Model_Description = '{cbUpdateDeleteMakeModel_ModelModel.Text}'";
                comm = new SqlCommand(sql, conn);
                adapt = new SqlDataAdapter();
                adapt.SelectCommand = comm;
                reader = comm.ExecuteReader();

                while (reader.Read())
                {
                    model_id = (int)reader.GetValue(0);
                    make_id = (int)reader.GetValue(1);  
                }
                reader.Close();


                if (model_id != 0)
                {
                    sql = "UPDATE Model ";
                    sql = sql + $"SET Model_Description = '{txtUpdateDeleteMakeModel_ModelModel.Text}'";
                    sql =sql + $"WHERE Vehicle_Model_id = {model_id}";
                    comm = new SqlCommand(sql, conn);
                    comm.ExecuteNonQuery();

                    MessageBox.Show(cbUpdateDeleteMakeModel_ModelModel.Text + " was updated successfully");

                    cbUpdateDeleteMakeModel_ModelMake.Text = "";
                    cbUpdateDeleteMakeModel_ModelModel.Text = "";
                    cbUpdateDeleteMakeModel_ModelModel.Items.Clear();
                    txtUpdateDeleteMakeModel_ModelModel.Text = "";
                    txtUpdateDeleteMakeModel_ModelMake.Text = "";

                    sql = $"SELECT a.Model_Description FROM Model a, Make b WHERE b.Vehicle_Make_ID = a.Vehicle_Make_ID AND a.Vehicle_Make_ID = {make_id} ";
                    comm = new SqlCommand(sql, conn);
                    adapt = new SqlDataAdapter();
                    adapt.SelectCommand = comm;
                    reader = comm.ExecuteReader();

                    while (reader.Read())
                    {
                        cbUpdateDeleteMakeModel_ModelModel.Items.Add(reader.GetValue(0));
                    }
                    reader.Close();

                    conn.Close();
                }
            }
        }

        private void btnUpdateDeleteMakeModel_UpdateMake_Click(object sender, EventArgs e)
        {
            if (cbUpdateDeleteMakeModel_MakeSelectMake.Text != "")
            {
                int make_id = 0;
                string make = txtUpdateDeleteMakeModel_MakeMake.Text;
                conn.Open();
                string sql = $"Select Vehicle_Make_ID FROM Make WHERE Make_Description = '{cbUpdateDeleteMakeModel_MakeSelectMake.Text}'";

                comm = new SqlCommand(sql, conn);
                adapt = new SqlDataAdapter();
                adapt.SelectCommand = comm;
                reader = comm.ExecuteReader();

                while (reader.Read())
                {
                    make_id = (int)reader.GetValue(0);
                }
                reader.Close();

                if (make_id != 0)
                {
                    sql = "UPDATE Make ";
                    sql = sql + $"SET Make_Description = '{make}'";
                    sql = sql + $"WHERE Vehicle_Make_ID = {make_id}";

                    comm = new SqlCommand(sql, conn);
                    reader = comm.ExecuteReader();

                    MessageBox.Show(cbUpdateDeleteMakeModel_MakeSelectMake.Text + " was updated successfully");
                    conn.Close();

                    cbUpdateDeleteMakeModel_MakeSelectMake.Text = "";
                    cbUpdateDeleteMakeModel_MakeSelectMake.Items.Clear();
                    txtUpdateDeleteMakeModel_MakeMake.Text = "";
                    cbUpdateDeleteMakeModel_ModelMake.Items.Clear ();

                    conn.Open();
                    sql = "SELECT DISTINCT Make_Description FROM Make";
                    comm = new SqlCommand(sql, conn);
                    adapt = new SqlDataAdapter();
                    adapt.SelectCommand = comm;
                    reader = comm.ExecuteReader();

                    make = "";
                    while (reader.Read())
                    {
                        make = reader.GetString(0);
                        cbUpdateDeleteMakeModel_MakeSelectMake.Items.Add(make);
                        cbUpdateDeleteMakeModel_ModelMake.Items.Add(make);
                    }
                    reader.Close();
                    conn.Close();
                }
                else
                {
                    MessageBox.Show("Please select a valid make");
                }
            }
            else
            {
                MessageBox.Show("Please select a make");
            }
        }

        private void ucUpdateDeleteMakeModel_Load(object sender, EventArgs e)
        {
            //MAKE
            conn.Open();
            string sql = "SELECT DISTINCT Make_Description FROM Make";
            comm = new SqlCommand(sql, conn);
            adapt = new SqlDataAdapter();
            adapt.SelectCommand = comm;
            reader = comm.ExecuteReader();

            while (reader.Read())
            {
                cbUpdateDeleteMakeModel_MakeSelectMake.Items.Add(reader.GetValue(0)); 
            }
            reader.Close();

            conn.Close();

            //MODEL
            int make_id = 0;
            conn.Open();
            sql = $"SELECT Vehicle_Make_id FROM Model WHERE Model_Description = '{cbUpdateDeleteMakeModel_ModelModel.Text}'";
            comm = new SqlCommand(sql, conn);
            adapt = new SqlDataAdapter();
            adapt.SelectCommand = comm;
            reader = comm.ExecuteReader();

            while (reader.Read())
            {
                make_id = (int)reader.GetValue(0);
            }
            reader.Close();
            sql = "SELECT DISTINCT Make_Description FROM Make ";
            comm = new SqlCommand(sql, conn);
            adapt = new SqlDataAdapter();
            adapt.SelectCommand = comm;
            reader = comm.ExecuteReader();

            while (reader.Read())
            {
                cbUpdateDeleteMakeModel_ModelMake.Items.Add(reader.GetValue(0));
            }
            reader.Close();

            conn.Close();

            conn.Open();
            sql = $"SELECT a.Model_Description FROM Model a, Make b WHERE b.Vehicle_Make_ID = a.Vehicle_Make_ID  AND a.Vehicle_Make_ID = {make_id}";
            comm = new SqlCommand(sql, conn);
            adapt = new SqlDataAdapter();
            adapt.SelectCommand = comm;
            reader = comm.ExecuteReader();

            while (reader.Read())
            {
                cbUpdateDeleteMakeModel_ModelModel.Items.Add(reader.GetValue(0));
            }
            reader.Close();

            conn.Close();
        }

        private void cbUpdateDeleteMakeModel_MakeSelectMake_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtUpdateDeleteMakeModel_MakeMake.Text = cbUpdateDeleteMakeModel_MakeSelectMake.Text;
        }

        private void btnUpdateDeleteMakeModel_DeleteModel_Click(object sender, EventArgs e)
        {
            if (cbUpdateDeleteMakeModel_ModelModel.Text != "")
            {
                string message = "Are you sure you want to delete '" + cbUpdateDeleteMakeModel_ModelModel.Text + "'?";
                string title = "WARNING!";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result = MessageBox.Show(message, title, buttons);
                if (result == DialogResult.Yes)
                {
                    conn.Open();
                    string sql = $"DELETE FROM Model WHERE Model_Description = '{cbUpdateDeleteMakeModel_ModelModel.Text}'";
                    comm = new SqlCommand(sql, conn);
                    comm.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show(cbUpdateDeleteMakeModel_ModelModel.Text + " was deleted successfully");

                    cbUpdateDeleteMakeModel_ModelMake.Text = "";
                    cbUpdateDeleteMakeModel_ModelModel.Text = "";
                    cbUpdateDeleteMakeModel_ModelModel.Items.Clear();
                    txtUpdateDeleteMakeModel_ModelMake.Text = "";
                    txtUpdateDeleteMakeModel_ModelModel.Text = "";
                    
                    conn.Open();
                    sql = "SELECT DISTINCT a.Model_Description FROM Model a, Make b WHERE b.Vehicle_Make_ID = a.Vehicle_Make_ID";
                    comm = new SqlCommand(sql, conn);
                    adapt = new SqlDataAdapter();
                    adapt.SelectCommand = comm;
                    reader = comm.ExecuteReader();

                    while (reader.Read())
                    {
                        cbUpdateDeleteMakeModel_ModelModel.Items.Add(reader.GetValue(0));
                    }
                    reader.Close();

                    conn.Close();
                }
            }
            else
            {
                MessageBox.Show("Please select a model");
            }
        }

        private void cbUpdateDeleteMakeModel_ModelMake_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtUpdateDeleteMakeModel_ModelMake.Text = cbUpdateDeleteMakeModel_ModelMake.Text;
            conn.Open();
            string sql = "SELECT DISTINCT Make_Description FROM Make ";
            comm = new SqlCommand(sql, conn);
            adapt = new SqlDataAdapter();
            adapt.SelectCommand = comm;
            reader = comm.ExecuteReader();
            conn.Close();

            cbUpdateDeleteMakeModel_ModelModel.Items.Clear();

            int make_id = 0;
            conn.Open();
            sql = $"SELECT Vehicle_Make_id FROM Make WHERE Make_Description = '{cbUpdateDeleteMakeModel_ModelMake.Text}'";//change
            comm = new SqlCommand(sql, conn);
            adapt = new SqlDataAdapter();
            adapt.SelectCommand = comm;
            reader = comm.ExecuteReader();

            while (reader.Read())
            {
                make_id = (int)reader.GetValue(0);
            }
            reader.Close();


            
            sql = $"SELECT a.Model_Description FROM Model a, Make b WHERE b.Vehicle_Make_ID = a.Vehicle_Make_ID AND a.Vehicle_Make_ID = {make_id}";
            comm = new SqlCommand(sql, conn);
            adapt = new SqlDataAdapter();
            adapt.SelectCommand = comm;
            reader = comm.ExecuteReader();

            while (reader.Read())
            {
                cbUpdateDeleteMakeModel_ModelModel.Items.Add(reader.GetValue(0));
            }
            reader.Close();

            conn.Close();
        }

        private void cbUpdateDeleteMakeModel_ModelModel_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtUpdateDeleteMakeModel_ModelModel.Text = cbUpdateDeleteMakeModel_ModelModel.Text;
        }
    }
}
