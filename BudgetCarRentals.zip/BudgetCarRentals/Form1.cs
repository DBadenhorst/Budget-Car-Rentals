﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BudgetCarRentals
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void rentToolStripMenuItem_Click(object sender, EventArgs e)
        {

            ucAddClient1.Hide();
            ucUpdateDeleteClient1.Hide();
            ucReturn1.Hide();
            ucAddVehicle1.Hide();
            ucAddMakeModel1.Hide();
            ucUpdateDeleteMakeModel1.Hide();

            ucRent1.Show();
            ucRent1.BringToFront();
        }

        private void returnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ucAddClient1.Hide();
            ucUpdateDeleteClient1.Hide();
            ucRent1.Hide();
            ucAddVehicle1.Hide();
            ucAddMakeModel1.Hide();
            ucUpdateDeleteMakeModel1.Hide();

            ucReturn1.Show();
            ucReturn1.BringToFront();
        }

        private void addClientToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ucUpdateDeleteClient1.Hide();
            ucRent1.Hide();
            ucReturn1.Hide();
            ucAddVehicle1.Hide();
            ucAddMakeModel1.Hide();
            ucUpdateDeleteMakeModel1.Hide();

            ucAddClient1.Show();
            ucAddClient1.BringToFront();
        }

        private void updateClientToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ucRent1.Hide();
            ucReturn1.Hide();
            ucAddClient1.Hide();
            ucAddVehicle1.Hide();
            ucAddMakeModel1.Hide();
            ucUpdateDeleteMakeModel1.Hide();

            ucUpdateDeleteClient1.Show();
            ucUpdateDeleteClient1.BringToFront();
        }

        private void addVehicleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ucRent1.Hide();
            ucReturn1.Hide();
            ucAddClient1.Hide();
            ucUpdateDeleteClient1.Hide();
            ucAddMakeModel1.Hide();
            ucUpdateDeleteMakeModel1.Hide();

            ucAddVehicle1.Show();
            ucAddVehicle1.BringToFront();
        }

        private void updateVehicleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ucRent1.Hide();
            ucReturn1.Hide();
            ucAddClient1.Hide();
            ucUpdateDeleteClient1.Hide();
            ucAddVehicle1.Hide();
            ucAddMakeModel1.Hide();
            ucUpdateDeleteMakeModel1.Hide();

            ucUpdateDeleteVehicle1.Show();
            ucUpdateDeleteVehicle1.BringToFront();
        }

        private void addMakeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ucRent1.Hide();
            ucReturn1.Hide();
            ucAddClient1.Hide();
            ucUpdateDeleteClient1.Hide();
            ucAddVehicle1.Hide();
            ucUpdateDeleteVehicle1.Hide();
            ucUpdateDeleteMakeModel1.Hide();

            ucAddMakeModel1.Show();
            ucAddMakeModel1.BringToFront();
        }

        private void updateMakeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ucRent1.Hide();
            ucReturn1.Hide();
            ucAddClient1.Hide();
            ucUpdateDeleteClient1.Hide();
            ucAddVehicle1.Hide();
            ucUpdateDeleteVehicle1.Hide();
            ucAddMakeModel1.Hide();

            ucUpdateDeleteMakeModel1.Show();
            ucUpdateDeleteMakeModel1.BringToFront();
        }
    }
}
