﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace BudgetCarRentals
{
    public partial class ucUpdateDeleteClient : UserControl
    {
        SqlConnection con = new SqlConnection(@"Data Source=JEANDRE-PC;Initial Catalog=Budget_Car_Rental_Data;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        SqlCommand comm;
        SqlDataAdapter adapt;
        SqlDataReader reader;
        int client_ID;
        string fName = "";
        string lName = "";  //initialising variables
        string cell = "";
        string licence = "";

        public ucUpdateDeleteClient()
        {
            InitializeComponent();
        }

        private void btnUpdateDeleteClient_Update_Click(object sender, EventArgs e)
        {
            fName = txtUpdateDeleteClient_Name.Text;
            lName = txtUpdateDeleteClient_Surname.Text;
            cell = txtUpdateDeleteClient_CellNumber.Text;
            licence = txtUpdateDeleteClient_LicenseNumber.Text;
            if (fName != "" || fName == " ")
            {
                if (lName != "" || fName == " ")
                {
                    if (cell.Length == 10)
                    {
                        if (licence.Length == 12)
                        {
                            con.Open();
                            string sql = "Update CLIENT_INFORMATION ";
                            sql = sql + $"Set Client_FName = '{fName}' , Client_LName = '{lName}' , Contact_No = '{cell}', Lisence_No = '{licence}' ";
                            sql = sql + $"WHERE Client_ID = {client_ID}";
                            comm = new SqlCommand(sql, con);  //Creating new SQL query
                            comm.ExecuteNonQuery();
                            con.Close();
                            MessageBox.Show("You updated: " + cbUpdateDeleteClient_SelectClient.Text);
                        }
                        else
                        {
                            txtUpdateDeleteClient_LicenseNumber.Focus();
                        }
                    }
                    else
                    {
                        txtUpdateDeleteClient_CellNumber.Focus();
                    }
                }
                else
                {
                    txtUpdateDeleteClient_Surname.Focus();
                }
            }
            else 
            {
                txtUpdateDeleteClient_Name.Focus();
            }
          
            //Repopulate the comboBox after update.
            cbUpdateDeleteClient_SelectClient.Items.Clear();
            con.Open();
            string sql2 = "SELECT * ";
            sql2 = sql2 + "FROM CLIENT_INFORMATION  ";
            comm = new SqlCommand(sql2, con);
            adapt = new SqlDataAdapter();   //Creating new SQL query
            adapt.SelectCommand = comm;
            reader = comm.ExecuteReader();


            while (reader.Read())
            {
                client_ID = (int)reader.GetValue(0);
                fName = reader.GetString(1);
                lName = reader.GetString(2); //getting value from the query
                cell = reader.GetString(3);

                string line = client_ID.ToString() + ". " + fName + " " + lName + " (" + cell + ")";
                cbUpdateDeleteClient_SelectClient.Items.Add(line);    //Adding items to the combo box
            }
            reader.Close();

            con.Close();
            txtUpdateDeleteClient_Name.Text = "";
            txtUpdateDeleteClient_Surname.Text = "";
            txtUpdateDeleteClient_CellNumber.Text = "";
            txtUpdateDeleteClient_LicenseNumber.Text = "";
            cbUpdateDeleteClient_SelectClient.SelectedIndex = -1;
        }

        private void ucUpdateDeleteClient_Load(object sender, EventArgs e)
        {
            txtUpdateDeleteClient_Name.Enabled = false;
            txtUpdateDeleteClient_Surname.Enabled = false;
            txtUpdateDeleteClient_CellNumber.Enabled = false;
            txtUpdateDeleteClient_LicenseNumber.Enabled = false;
            cbUpdateDeleteClient_SelectClient.Items.Clear();
            con.Open();
            string sql = "SELECT * ";
            sql = sql + "FROM CLIENT_INFORMATION  ";
            comm = new SqlCommand(sql, con);
            adapt = new SqlDataAdapter();   //Creating new SQL query
            adapt.SelectCommand = comm;
            reader = comm.ExecuteReader();

           
            while (reader.Read())
            {
                client_ID = (int)reader.GetValue(0);
                fName = reader.GetString(1);
                lName = reader.GetString(2); //getting value from the query
                cell = reader.GetString(3);

                string line = client_ID.ToString()+". " + fName + " " + lName + " (" + cell + ")";
                cbUpdateDeleteClient_SelectClient.Items.Add(line);    //Adding items to the combo box
            }
            reader.Close();

            con.Close();
        }

        private void cbUpdateDeleteClient_SelectClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtUpdateDeleteClient_Name.Enabled = true;
            txtUpdateDeleteClient_Surname.Enabled = true;
            txtUpdateDeleteClient_CellNumber.Enabled = true;
            txtUpdateDeleteClient_LicenseNumber.Enabled = true;
            con.Open();
            string sql = "SELECT * ";
            sql = sql + "FROM CLIENT_INFORMATION  ";
            sql = sql + $"Where CHARINDEX(Contact_No, '{cbUpdateDeleteClient_SelectClient.Text}') > 0";//Client_ID = { cbUpdateDeleteClient_SelectClient.SelectedItem.ToString().Substring(0,2)} ";
            comm = new SqlCommand(sql, con);
            adapt = new SqlDataAdapter();   //Creating new SQL query
            adapt.SelectCommand = comm;
            reader = comm.ExecuteReader();
        
            while (reader.Read())
            {
                client_ID = (int)reader.GetValue(0);
                fName = reader.GetString(1);
                lName = reader.GetString(2); //getting value from the query
                cell = reader.GetString(3);
                licence = reader.GetString(4);

                txtUpdateDeleteClient_Name.Text = fName;
                txtUpdateDeleteClient_Surname.Text = lName;
                txtUpdateDeleteClient_CellNumber.Text = cell;
                txtUpdateDeleteClient_LicenseNumber.Text = licence; 
                

            }
            reader.Close();

            con.Close();
        }

        private void btnUpdateDeleteClient_Delete_Click(object sender, EventArgs e)
        {
            string message = "Are you sure you want to delete '" + cbUpdateDeleteClient_SelectClient.Text + "'?";
            string title = "WARNING!";  //Creating warning dialog
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(message, title, buttons);

            if (result == DialogResult.Yes)
            {
                con.Open();
                string sql = "DELETE FROM ";
                sql = sql + $"CLIENT_INFORMATION ";
                sql = sql + $"WHERE Client_ID = {client_ID}";
                comm = new SqlCommand(sql, con);  //Creating new SQL query
                comm.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("You deleted record number: " + cbUpdateDeleteClient_SelectClient.Text);
            }


            //Repopulate the comboBox after update.
            cbUpdateDeleteClient_SelectClient.Items.Clear();
            con.Open();
            string sql2 = "SELECT * ";
            sql2 = sql2 + "FROM CLIENT_INFORMATION  ";
            comm = new SqlCommand(sql2, con);
            adapt = new SqlDataAdapter();   //Creating new SQL query
            adapt.SelectCommand = comm;
            reader = comm.ExecuteReader();


            while (reader.Read())
            {
                client_ID = (int)reader.GetValue(0);
                fName = reader.GetString(1);
                lName = reader.GetString(2); //getting value from the query
                cell = reader.GetString(3);

                string line = client_ID.ToString() + ". " + fName + " " + lName + " (" + cell + ")";
                cbUpdateDeleteClient_SelectClient.Items.Add(line);    //Adding items to the combo box
            }
            reader.Close();
            
            txtUpdateDeleteClient_Name.Text = "";
            txtUpdateDeleteClient_Surname.Text = "";
            txtUpdateDeleteClient_CellNumber.Text = "";
            txtUpdateDeleteClient_LicenseNumber.Text = "";
            con.Close();
            cbUpdateDeleteClient_SelectClient.SelectedIndex = -1;
        }
    }
}
