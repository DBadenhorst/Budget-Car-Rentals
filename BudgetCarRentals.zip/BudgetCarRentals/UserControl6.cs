﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BudgetCarRentals
{
    public partial class ucUpdateDeleteVehicle : UserControl
    {
        SqlConnection con = new SqlConnection(@"Data Source=JEANDRE-PC;Initial Catalog=Budget_Car_Rental_Data;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        SqlCommand comm;
        SqlDataAdapter adapt;   //Creating databse connection variables
        SqlDataReader reader;

        public ucUpdateDeleteVehicle()
        {
            InitializeComponent();
        }

        //Creating a method to reset the form to
        //Reusable code
        private void populateForm()
        {
            cbUpdateDeleteVehicle_SelectVehicle.Text = "";
            txtUpdateDeleteVehicle_Cost.Text = "";
            txtUpdateDeleteVehicle_Make.Text = "";  //Clearing inpputs
            txtUpdateDeleteVehicle_Model.Text = "";
            txtUpdateDeleteVehicle_Registration.Text = "";

            cbUpdateDeleteVehicle_SelectVehicle.Items.Clear();
            con.Open();
            string sql = "SELECT v.Registration, mk.Make_Description, mo.Model_Description ";
            sql = sql + "FROM Vehicle v, Make mk, Model mo ";
            sql = sql + "WHERE v.Vehicle_Model_id = mo.Vehicle_Model_id AND ";
            sql = sql + "mo.Vehicle_Make_ID = mk.Vehicle_Make_ID";
            comm = new SqlCommand(sql, con);
            adapt = new SqlDataAdapter();   //Getting the identifying info for a vehicle
            adapt.SelectCommand = comm;
            reader = comm.ExecuteReader();

            //Repopulating the combo box
            string make = "";
            string model = "";
            string reg = "";
            while (reader.Read())
            {
                reg = reader.GetString(0);
                make = reader.GetString(1);
                model = reader.GetString(2);

                string line = make + " " + model + " (" + reg + ")";
                cbUpdateDeleteVehicle_SelectVehicle.Items.Add(line);
            }
            reader.Close();

            con.Close();
        }

        private void ucUpdateDeleteVehicle_Load(object sender, EventArgs e)
        {
            populateForm();
        }

        private void cbUpdateDeleteVehicle_SelectVehicle_SelectedIndexChanged(object sender, EventArgs e)
        {
            con.Open();
            string sql = "SELECT v.Registration, v.Cost, mk.Make_Description, mo.Model_Description ";
            sql = sql + "FROM Vehicle v, Make mk, Model mo ";
            sql = sql + "WHERE v.Vehicle_Model_id = mo.Vehicle_Model_id AND ";  //Creating new SQL query
            sql = sql + "mo.Vehicle_Make_ID = mk.Vehicle_Make_ID AND ";         //To select the details of a vehicle
            sql = sql + $"CHARINDEX(v.Registration, '{cbUpdateDeleteVehicle_SelectVehicle.Text}') > 0";
            comm = new SqlCommand(sql, con);
            adapt = new SqlDataAdapter(); 
            adapt.SelectCommand = comm;
            reader = comm.ExecuteReader();

            while (reader.Read())
            {
                txtUpdateDeleteVehicle_Registration.Text = reader.GetString(0);
                string cost = (reader.GetValue(1)).ToString();
                txtUpdateDeleteVehicle_Cost.Text = cost;
                txtUpdateDeleteVehicle_Make.Text = reader.GetString(2); //Adding text to the text boxes
                txtUpdateDeleteVehicle_Model.Text = reader.GetString(3);
            }
            reader.Close();

            con.Close();
        }

        private void btnUpdateDeleteVehicle_Delete_Click(object sender, EventArgs e)
        {
            if (cbUpdateDeleteVehicle_SelectVehicle.Text != "")
            {
                string message = "Are you sure you want to delete '" + cbUpdateDeleteVehicle_SelectVehicle.Text + "'?";
                string title = "WARNING!";  //Creating warning dialog
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result = MessageBox.Show(message, title, buttons);

                if (result == DialogResult.Yes)
                {
                    con.Open();

                    string sql = $"DELETE FROM Vehicle WHERE Registration = '{txtUpdateDeleteVehicle_Registration.Text}'";
                    comm = new SqlCommand(sql, con);    //Creating new sql delete statement
                    comm.ExecuteNonQuery();

                    con.Close();

                    MessageBox.Show(cbUpdateDeleteVehicle_SelectVehicle.Text + " was deleted successfully!");

                    populateForm();

                }
            }
            else
            {
                MessageBox.Show("Please select a Vehicle!");
            }
        }

        private void btnUpdateDeleteVehicle_Update_Click(object sender, EventArgs e)
        {
            double update_cost;
            if (cbUpdateDeleteVehicle_SelectVehicle.Text != "")
            {
                if (double.TryParse(txtUpdateDeleteVehicle_Cost.Text, out update_cost))
                {
                    int model_id = 0;
                    int make_id = 0;
                    string reg = txtUpdateDeleteVehicle_Registration.Text;  //Getting input from user
                    string make = txtUpdateDeleteVehicle_Make.Text;
                    string model = txtUpdateDeleteVehicle_Model.Text;
                    int id = 0;
                    con.Open();
                    string sql = $"SELECT Vehicle_ID FROM Vehicle WHERE Registration = '{reg}'";
                    comm = new SqlCommand(sql, con);
                    adapt = new SqlDataAdapter();   //Selecting the primary key of the vehicle
                    adapt.SelectCommand = comm;
                    reader = comm.ExecuteReader();

                    while (reader.Read())
                    {
                        id = (int)reader.GetValue(0);
                    }
                    reader.Close();

                    sql = $"SELECT Vehicle_Make_ID FROM Make WHERE Make_Description = '{make}'";
                    comm = new SqlCommand(sql, con);
                    adapt = new SqlDataAdapter();   //getting the primary key of make
                    adapt.SelectCommand = comm;
                    reader = comm.ExecuteReader();

                    while (reader.Read())
                    {
                        make_id = (int)reader.GetValue(0);
                    }
                    reader.Close();

                    sql = $"SELECT Vehicle_Model_id FROM Model WHERE Model_Description = '{model}'";
                    comm = new SqlCommand(sql, con);
                    adapt = new SqlDataAdapter();   //Getting the primary key of model
                    adapt.SelectCommand = comm;
                    reader = comm.ExecuteReader();

                    while (reader.Read())
                    {
                        model_id = (int)reader.GetValue(0);
                    }
                    reader.Close();
          
                    if (make_id != 0 && model_id != 0 && id != 0)//Validation
                    {
                        //Updatign the databse with user input
                        sql = "UPDATE Vehicle ";
                        sql = sql + $"SET  Vehicle_Make_ID = {make_id}, Vehicle_Model_id = {model_id}, ";
                        sql = sql + $"Registration = '{reg}', Cost = {update_cost} ";
                        sql = sql + $"WHERE Vehicle_ID = {id}";
                        comm = new SqlCommand(sql, con);
                        comm.ExecuteNonQuery();

                        MessageBox.Show(cbUpdateDeleteVehicle_SelectVehicle.Text + " was updated successfully!");
                        con.Close();
                        populateForm();

                    }
                    else
                    {
                        MessageBox.Show("Please enter a valid registration, make or model!");
                    }
                }
                else
                {
                    MessageBox.Show("Please enter the cost in the correct format!");
                }
            }
            else
            {
                MessageBox.Show("Please select a Vehicle!");
            }
        }

        private void ucUpdateDeleteVehicle_Enter(object sender, EventArgs e)
        {
            populateForm();
        }
    }
}
