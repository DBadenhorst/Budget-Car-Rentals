﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BudgetCarRentals
{
    public partial class UCRent : UserControl
    {
        public UCRent()
        {
            InitializeComponent();
        }

        private void btnRent_Confirm_Click(object sender, EventArgs e)
        {

        }
    }
}
