﻿namespace BudgetCarRentals
{
    partial class ucUpdateDeleteClient
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblUpdateDeleteClient_SelectClient = new System.Windows.Forms.Label();
            this.lblUpdateDeleteClient_Name = new System.Windows.Forms.Label();
            this.lblUpdateDeleteClient_Surname = new System.Windows.Forms.Label();
            this.lblUpdateDeleteClient_CellNumber = new System.Windows.Forms.Label();
            this.lblUpdateDeleteClient_LicenseNumber = new System.Windows.Forms.Label();
            this.cbUpdateDeleteClient_SelectClient = new System.Windows.Forms.ComboBox();
            this.txtUpdateDeleteClient_Name = new System.Windows.Forms.TextBox();
            this.txtUpdateDeleteClient_Surname = new System.Windows.Forms.TextBox();
            this.txtUpdateDeleteClient_CellNumber = new System.Windows.Forms.TextBox();
            this.txtUpdateDeleteClient_LicenseNumber = new System.Windows.Forms.TextBox();
            this.btnUpdateDeleteClient_Update = new System.Windows.Forms.Button();
            this.btnUpdateDeleteClient_Delete = new System.Windows.Forms.Button();
            this.lblUpdateDeleteClient_Title = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblUpdateDeleteClient_SelectClient
            // 
            this.lblUpdateDeleteClient_SelectClient.AutoSize = true;
            this.lblUpdateDeleteClient_SelectClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateDeleteClient_SelectClient.ForeColor = System.Drawing.Color.White;
            this.lblUpdateDeleteClient_SelectClient.Location = new System.Drawing.Point(490, 138);
            this.lblUpdateDeleteClient_SelectClient.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUpdateDeleteClient_SelectClient.Name = "lblUpdateDeleteClient_SelectClient";
            this.lblUpdateDeleteClient_SelectClient.Size = new System.Drawing.Size(102, 20);
            this.lblUpdateDeleteClient_SelectClient.TabIndex = 0;
            this.lblUpdateDeleteClient_SelectClient.Text = "Select Client:";
            // 
            // lblUpdateDeleteClient_Name
            // 
            this.lblUpdateDeleteClient_Name.AutoSize = true;
            this.lblUpdateDeleteClient_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateDeleteClient_Name.ForeColor = System.Drawing.Color.White;
            this.lblUpdateDeleteClient_Name.Location = new System.Drawing.Point(396, 229);
            this.lblUpdateDeleteClient_Name.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUpdateDeleteClient_Name.Name = "lblUpdateDeleteClient_Name";
            this.lblUpdateDeleteClient_Name.Size = new System.Drawing.Size(55, 20);
            this.lblUpdateDeleteClient_Name.TabIndex = 1;
            this.lblUpdateDeleteClient_Name.Text = "Name:";
            // 
            // lblUpdateDeleteClient_Surname
            // 
            this.lblUpdateDeleteClient_Surname.AutoSize = true;
            this.lblUpdateDeleteClient_Surname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateDeleteClient_Surname.ForeColor = System.Drawing.Color.White;
            this.lblUpdateDeleteClient_Surname.Location = new System.Drawing.Point(620, 229);
            this.lblUpdateDeleteClient_Surname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUpdateDeleteClient_Surname.Name = "lblUpdateDeleteClient_Surname";
            this.lblUpdateDeleteClient_Surname.Size = new System.Drawing.Size(78, 20);
            this.lblUpdateDeleteClient_Surname.TabIndex = 2;
            this.lblUpdateDeleteClient_Surname.Text = "Surname:";
            // 
            // lblUpdateDeleteClient_CellNumber
            // 
            this.lblUpdateDeleteClient_CellNumber.AutoSize = true;
            this.lblUpdateDeleteClient_CellNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateDeleteClient_CellNumber.ForeColor = System.Drawing.Color.White;
            this.lblUpdateDeleteClient_CellNumber.Location = new System.Drawing.Point(396, 334);
            this.lblUpdateDeleteClient_CellNumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUpdateDeleteClient_CellNumber.Name = "lblUpdateDeleteClient_CellNumber";
            this.lblUpdateDeleteClient_CellNumber.Size = new System.Drawing.Size(99, 20);
            this.lblUpdateDeleteClient_CellNumber.TabIndex = 3;
            this.lblUpdateDeleteClient_CellNumber.Text = "Cell Number:";
            // 
            // lblUpdateDeleteClient_LicenseNumber
            // 
            this.lblUpdateDeleteClient_LicenseNumber.AutoSize = true;
            this.lblUpdateDeleteClient_LicenseNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateDeleteClient_LicenseNumber.ForeColor = System.Drawing.Color.White;
            this.lblUpdateDeleteClient_LicenseNumber.Location = new System.Drawing.Point(620, 334);
            this.lblUpdateDeleteClient_LicenseNumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUpdateDeleteClient_LicenseNumber.Name = "lblUpdateDeleteClient_LicenseNumber";
            this.lblUpdateDeleteClient_LicenseNumber.Size = new System.Drawing.Size(128, 20);
            this.lblUpdateDeleteClient_LicenseNumber.TabIndex = 4;
            this.lblUpdateDeleteClient_LicenseNumber.Text = "License Number:";
            // 
            // cbUpdateDeleteClient_SelectClient
            // 
            this.cbUpdateDeleteClient_SelectClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbUpdateDeleteClient_SelectClient.FormattingEnabled = true;
            this.cbUpdateDeleteClient_SelectClient.Location = new System.Drawing.Point(474, 161);
            this.cbUpdateDeleteClient_SelectClient.Margin = new System.Windows.Forms.Padding(2);
            this.cbUpdateDeleteClient_SelectClient.Name = "cbUpdateDeleteClient_SelectClient";
            this.cbUpdateDeleteClient_SelectClient.Size = new System.Drawing.Size(282, 28);
            this.cbUpdateDeleteClient_SelectClient.TabIndex = 5;
            this.cbUpdateDeleteClient_SelectClient.SelectedIndexChanged += new System.EventHandler(this.cbUpdateDeleteClient_SelectClient_SelectedIndexChanged);
            // 
            // txtUpdateDeleteClient_Name
            // 
            this.txtUpdateDeleteClient_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUpdateDeleteClient_Name.Location = new System.Drawing.Point(400, 252);
            this.txtUpdateDeleteClient_Name.Margin = new System.Windows.Forms.Padding(2);
            this.txtUpdateDeleteClient_Name.Name = "txtUpdateDeleteClient_Name";
            this.txtUpdateDeleteClient_Name.Size = new System.Drawing.Size(175, 26);
            this.txtUpdateDeleteClient_Name.TabIndex = 6;
            // 
            // txtUpdateDeleteClient_Surname
            // 
            this.txtUpdateDeleteClient_Surname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUpdateDeleteClient_Surname.Location = new System.Drawing.Point(624, 252);
            this.txtUpdateDeleteClient_Surname.Margin = new System.Windows.Forms.Padding(2);
            this.txtUpdateDeleteClient_Surname.Name = "txtUpdateDeleteClient_Surname";
            this.txtUpdateDeleteClient_Surname.Size = new System.Drawing.Size(175, 26);
            this.txtUpdateDeleteClient_Surname.TabIndex = 7;
            // 
            // txtUpdateDeleteClient_CellNumber
            // 
            this.txtUpdateDeleteClient_CellNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUpdateDeleteClient_CellNumber.Location = new System.Drawing.Point(400, 357);
            this.txtUpdateDeleteClient_CellNumber.Margin = new System.Windows.Forms.Padding(2);
            this.txtUpdateDeleteClient_CellNumber.Name = "txtUpdateDeleteClient_CellNumber";
            this.txtUpdateDeleteClient_CellNumber.Size = new System.Drawing.Size(175, 26);
            this.txtUpdateDeleteClient_CellNumber.TabIndex = 8;
            // 
            // txtUpdateDeleteClient_LicenseNumber
            // 
            this.txtUpdateDeleteClient_LicenseNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUpdateDeleteClient_LicenseNumber.Location = new System.Drawing.Point(624, 357);
            this.txtUpdateDeleteClient_LicenseNumber.Margin = new System.Windows.Forms.Padding(2);
            this.txtUpdateDeleteClient_LicenseNumber.Name = "txtUpdateDeleteClient_LicenseNumber";
            this.txtUpdateDeleteClient_LicenseNumber.Size = new System.Drawing.Size(175, 26);
            this.txtUpdateDeleteClient_LicenseNumber.TabIndex = 9;
            // 
            // btnUpdateDeleteClient_Update
            // 
            this.btnUpdateDeleteClient_Update.BackColor = System.Drawing.Color.DimGray;
            this.btnUpdateDeleteClient_Update.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateDeleteClient_Update.Location = new System.Drawing.Point(486, 414);
            this.btnUpdateDeleteClient_Update.Margin = new System.Windows.Forms.Padding(2);
            this.btnUpdateDeleteClient_Update.Name = "btnUpdateDeleteClient_Update";
            this.btnUpdateDeleteClient_Update.Size = new System.Drawing.Size(88, 30);
            this.btnUpdateDeleteClient_Update.TabIndex = 10;
            this.btnUpdateDeleteClient_Update.Text = "Update";
            this.btnUpdateDeleteClient_Update.UseVisualStyleBackColor = false;
            this.btnUpdateDeleteClient_Update.Click += new System.EventHandler(this.btnUpdateDeleteClient_Update_Click);
            // 
            // btnUpdateDeleteClient_Delete
            // 
            this.btnUpdateDeleteClient_Delete.BackColor = System.Drawing.Color.DimGray;
            this.btnUpdateDeleteClient_Delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateDeleteClient_Delete.Location = new System.Drawing.Point(624, 414);
            this.btnUpdateDeleteClient_Delete.Margin = new System.Windows.Forms.Padding(2);
            this.btnUpdateDeleteClient_Delete.Name = "btnUpdateDeleteClient_Delete";
            this.btnUpdateDeleteClient_Delete.Size = new System.Drawing.Size(88, 30);
            this.btnUpdateDeleteClient_Delete.TabIndex = 11;
            this.btnUpdateDeleteClient_Delete.Text = "Delete";
            this.btnUpdateDeleteClient_Delete.UseVisualStyleBackColor = false;
            this.btnUpdateDeleteClient_Delete.Click += new System.EventHandler(this.btnUpdateDeleteClient_Delete_Click);
            // 
            // lblUpdateDeleteClient_Title
            // 
            this.lblUpdateDeleteClient_Title.AutoSize = true;
            this.lblUpdateDeleteClient_Title.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateDeleteClient_Title.ForeColor = System.Drawing.Color.White;
            this.lblUpdateDeleteClient_Title.Location = new System.Drawing.Point(12, 15);
            this.lblUpdateDeleteClient_Title.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUpdateDeleteClient_Title.Name = "lblUpdateDeleteClient_Title";
            this.lblUpdateDeleteClient_Title.Size = new System.Drawing.Size(177, 20);
            this.lblUpdateDeleteClient_Title.TabIndex = 12;
            this.lblUpdateDeleteClient_Title.Text = "Update/Delete Client";
            // 
            // ucUpdateDeleteClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.lblUpdateDeleteClient_Title);
            this.Controls.Add(this.btnUpdateDeleteClient_Delete);
            this.Controls.Add(this.btnUpdateDeleteClient_Update);
            this.Controls.Add(this.txtUpdateDeleteClient_LicenseNumber);
            this.Controls.Add(this.txtUpdateDeleteClient_CellNumber);
            this.Controls.Add(this.txtUpdateDeleteClient_Surname);
            this.Controls.Add(this.txtUpdateDeleteClient_Name);
            this.Controls.Add(this.cbUpdateDeleteClient_SelectClient);
            this.Controls.Add(this.lblUpdateDeleteClient_LicenseNumber);
            this.Controls.Add(this.lblUpdateDeleteClient_CellNumber);
            this.Controls.Add(this.lblUpdateDeleteClient_Surname);
            this.Controls.Add(this.lblUpdateDeleteClient_Name);
            this.Controls.Add(this.lblUpdateDeleteClient_SelectClient);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ucUpdateDeleteClient";
            this.Size = new System.Drawing.Size(1214, 486);
            this.Load += new System.EventHandler(this.ucUpdateDeleteClient_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblUpdateDeleteClient_SelectClient;
        private System.Windows.Forms.Label lblUpdateDeleteClient_Name;
        private System.Windows.Forms.Label lblUpdateDeleteClient_Surname;
        private System.Windows.Forms.Label lblUpdateDeleteClient_CellNumber;
        private System.Windows.Forms.Label lblUpdateDeleteClient_LicenseNumber;
        private System.Windows.Forms.ComboBox cbUpdateDeleteClient_SelectClient;
        private System.Windows.Forms.TextBox txtUpdateDeleteClient_Name;
        private System.Windows.Forms.TextBox txtUpdateDeleteClient_Surname;
        private System.Windows.Forms.TextBox txtUpdateDeleteClient_CellNumber;
        private System.Windows.Forms.TextBox txtUpdateDeleteClient_LicenseNumber;
        private System.Windows.Forms.Button btnUpdateDeleteClient_Update;
        private System.Windows.Forms.Button btnUpdateDeleteClient_Delete;
        private System.Windows.Forms.Label lblUpdateDeleteClient_Title;
    }
}
