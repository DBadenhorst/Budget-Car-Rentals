﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace BudgetCarRentals
{
    public partial class ucAddClient : UserControl
    {

        SqlConnection con = new SqlConnection(@"Data Source=JEANDRE-PC;Initial Catalog=Budget_Car_Rental_Data;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        SqlCommand comm;
        public ucAddClient()
        {
            InitializeComponent();
        }

        private void btnAddClient_Add_Click(object sender, EventArgs e)
        { 
            String name, LName, contactNo, licenceNo;
            
            name = txtAddClient_Name.Text;
            LName = txtAddClient_Surname.Text;
            
            contactNo = txtAddClient_CellNumber.Text;
            licenceNo = txtAddClient_LicenseNumber.Text;
            if (txtAddClient_Name.Text != "" || txtAddClient_Name.Text == " ")
            {
                if (txtAddClient_Surname.Text != "" || txtAddClient_Surname.Text == " ")
                {
                    if (contactNo.Length == 10)
                    {
                        if (licenceNo.Length == 12)
                        {
                            con.Open();
                            string sql = $"Insert Into CLIENT_INFORMATION (Client_FName,Client_LName,Contact_No,Lisence_No) Values ('{name}','{LName}','{contactNo}','{licenceNo}')";
                            comm = new SqlCommand(sql, con);
                            comm.ExecuteNonQuery();
                            MessageBox.Show("Record was added successfully.");
                            con.Close();
                            txtAddClient_Name.Clear();
                            txtAddClient_LicenseNumber.Clear();
                            txtAddClient_Surname.Clear();
                            txtAddClient_CellNumber.Clear();
                            txtAddClient_Name.Focus();
                        }
                        else
                        {
                            txtAddClient_LicenseNumber.Clear();
                            txtAddClient_LicenseNumber.Focus();
                        }
                    }
                    else
                    {
                        txtAddClient_CellNumber.Clear();
                        txtAddClient_CellNumber.Focus();
                    }
                }
                else
                {
                    txtAddClient_Surname.Clear();
                    txtAddClient_Surname.Focus();
                }
            }
            else 
            {
                txtAddClient_Name.Clear();
                txtAddClient_Name.Focus();
            }
            
            
            
            
        }

        private void ucAddClient_Load(object sender, EventArgs e)
        {

        }
    }
}
