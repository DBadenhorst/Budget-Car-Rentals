﻿namespace BudgetCarRentals
{
    partial class UCRent
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRent_SelectClient = new System.Windows.Forms.Label();
            this.lblRent_RentDate = new System.Windows.Forms.Label();
            this.lblRent_ReturnDate = new System.Windows.Forms.Label();
            this.lblRent_SelectVehicle = new System.Windows.Forms.Label();
            this.lblRent_EstimateCost = new System.Windows.Forms.Label();
            this.cbRent_SelectClient = new System.Windows.Forms.ComboBox();
            this.cbRent_SelectVehicle = new System.Windows.Forms.ComboBox();
            this.datetimeRent_RentDate = new System.Windows.Forms.DateTimePicker();
            this.datetimeRent_ReturnDate = new System.Windows.Forms.DateTimePicker();
            this.btnRent_Confirm = new System.Windows.Forms.Button();
            this.lblRent_CostTotal = new System.Windows.Forms.Label();
            this.btnRent_AddClient = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblRent_Title = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblRent_SelectClient
            // 
            this.lblRent_SelectClient.AutoSize = true;
            this.lblRent_SelectClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRent_SelectClient.ForeColor = System.Drawing.Color.White;
            this.lblRent_SelectClient.Location = new System.Drawing.Point(145, 100);
            this.lblRent_SelectClient.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRent_SelectClient.Name = "lblRent_SelectClient";
            this.lblRent_SelectClient.Size = new System.Drawing.Size(102, 20);
            this.lblRent_SelectClient.TabIndex = 0;
            this.lblRent_SelectClient.Text = "Select Client:";
            // 
            // lblRent_RentDate
            // 
            this.lblRent_RentDate.AutoSize = true;
            this.lblRent_RentDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRent_RentDate.ForeColor = System.Drawing.Color.White;
            this.lblRent_RentDate.Location = new System.Drawing.Point(498, 102);
            this.lblRent_RentDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRent_RentDate.Name = "lblRent_RentDate";
            this.lblRent_RentDate.Size = new System.Drawing.Size(87, 20);
            this.lblRent_RentDate.TabIndex = 1;
            this.lblRent_RentDate.Text = "Rent Date:";
            // 
            // lblRent_ReturnDate
            // 
            this.lblRent_ReturnDate.AutoSize = true;
            this.lblRent_ReturnDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRent_ReturnDate.ForeColor = System.Drawing.Color.White;
            this.lblRent_ReturnDate.Location = new System.Drawing.Point(796, 102);
            this.lblRent_ReturnDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRent_ReturnDate.Name = "lblRent_ReturnDate";
            this.lblRent_ReturnDate.Size = new System.Drawing.Size(101, 20);
            this.lblRent_ReturnDate.TabIndex = 2;
            this.lblRent_ReturnDate.Text = "Return Date:";
            // 
            // lblRent_SelectVehicle
            // 
            this.lblRent_SelectVehicle.AutoSize = true;
            this.lblRent_SelectVehicle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRent_SelectVehicle.ForeColor = System.Drawing.Color.White;
            this.lblRent_SelectVehicle.Location = new System.Drawing.Point(145, 196);
            this.lblRent_SelectVehicle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRent_SelectVehicle.Name = "lblRent_SelectVehicle";
            this.lblRent_SelectVehicle.Size = new System.Drawing.Size(114, 20);
            this.lblRent_SelectVehicle.TabIndex = 3;
            this.lblRent_SelectVehicle.Text = "Select Vehicle:";
            // 
            // lblRent_EstimateCost
            // 
            this.lblRent_EstimateCost.AutoSize = true;
            this.lblRent_EstimateCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRent_EstimateCost.ForeColor = System.Drawing.Color.White;
            this.lblRent_EstimateCost.Location = new System.Drawing.Point(530, 370);
            this.lblRent_EstimateCost.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRent_EstimateCost.Name = "lblRent_EstimateCost";
            this.lblRent_EstimateCost.Size = new System.Drawing.Size(117, 20);
            this.lblRent_EstimateCost.TabIndex = 4;
            this.lblRent_EstimateCost.Text = "Estimate Cost: ";
            // 
            // cbRent_SelectClient
            // 
            this.cbRent_SelectClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbRent_SelectClient.FormattingEnabled = true;
            this.cbRent_SelectClient.Location = new System.Drawing.Point(148, 123);
            this.cbRent_SelectClient.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cbRent_SelectClient.Name = "cbRent_SelectClient";
            this.cbRent_SelectClient.Size = new System.Drawing.Size(184, 28);
            this.cbRent_SelectClient.TabIndex = 5;
            // 
            // cbRent_SelectVehicle
            // 
            this.cbRent_SelectVehicle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbRent_SelectVehicle.FormattingEnabled = true;
            this.cbRent_SelectVehicle.Location = new System.Drawing.Point(148, 219);
            this.cbRent_SelectVehicle.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cbRent_SelectVehicle.Name = "cbRent_SelectVehicle";
            this.cbRent_SelectVehicle.Size = new System.Drawing.Size(184, 28);
            this.cbRent_SelectVehicle.TabIndex = 6;
            // 
            // datetimeRent_RentDate
            // 
            this.datetimeRent_RentDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datetimeRent_RentDate.Location = new System.Drawing.Point(502, 125);
            this.datetimeRent_RentDate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.datetimeRent_RentDate.Name = "datetimeRent_RentDate";
            this.datetimeRent_RentDate.Size = new System.Drawing.Size(265, 26);
            this.datetimeRent_RentDate.TabIndex = 7;
            // 
            // datetimeRent_ReturnDate
            // 
            this.datetimeRent_ReturnDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datetimeRent_ReturnDate.Location = new System.Drawing.Point(800, 125);
            this.datetimeRent_ReturnDate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.datetimeRent_ReturnDate.Name = "datetimeRent_ReturnDate";
            this.datetimeRent_ReturnDate.Size = new System.Drawing.Size(265, 26);
            this.datetimeRent_ReturnDate.TabIndex = 8;
            // 
            // btnRent_Confirm
            // 
            this.btnRent_Confirm.BackColor = System.Drawing.Color.DimGray;
            this.btnRent_Confirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRent_Confirm.ForeColor = System.Drawing.Color.Black;
            this.btnRent_Confirm.Location = new System.Drawing.Point(1083, 422);
            this.btnRent_Confirm.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnRent_Confirm.Name = "btnRent_Confirm";
            this.btnRent_Confirm.Size = new System.Drawing.Size(111, 41);
            this.btnRent_Confirm.TabIndex = 10;
            this.btnRent_Confirm.Text = "Confirm";
            this.btnRent_Confirm.UseVisualStyleBackColor = false;
            this.btnRent_Confirm.Click += new System.EventHandler(this.btnRent_Confirm_Click);
            // 
            // lblRent_CostTotal
            // 
            this.lblRent_CostTotal.AutoSize = true;
            this.lblRent_CostTotal.BackColor = System.Drawing.Color.Transparent;
            this.lblRent_CostTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRent_CostTotal.ForeColor = System.Drawing.Color.White;
            this.lblRent_CostTotal.Location = new System.Drawing.Point(27, 28);
            this.lblRent_CostTotal.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRent_CostTotal.Name = "lblRent_CostTotal";
            this.lblRent_CostTotal.Size = new System.Drawing.Size(100, 26);
            this.lblRent_CostTotal.TabIndex = 11;
            this.lblRent_CostTotal.Text = "R 650.20";
            this.lblRent_CostTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnRent_AddClient
            // 
            this.btnRent_AddClient.BackColor = System.Drawing.Color.DimGray;
            this.btnRent_AddClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRent_AddClient.Location = new System.Drawing.Point(344, 123);
            this.btnRent_AddClient.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnRent_AddClient.Name = "btnRent_AddClient";
            this.btnRent_AddClient.Size = new System.Drawing.Size(92, 27);
            this.btnRent_AddClient.TabIndex = 12;
            this.btnRent_AddClient.Text = "Add Client";
            this.btnRent_AddClient.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel1.BackColor = System.Drawing.Color.DimGray;
            this.panel1.Controls.Add(this.lblRent_CostTotal);
            this.panel1.Location = new System.Drawing.Point(533, 393);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(150, 81);
            this.panel1.TabIndex = 13;
            // 
            // lblRent_Title
            // 
            this.lblRent_Title.AutoSize = true;
            this.lblRent_Title.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRent_Title.ForeColor = System.Drawing.Color.White;
            this.lblRent_Title.Location = new System.Drawing.Point(3, 3);
            this.lblRent_Title.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRent_Title.Name = "lblRent_Title";
            this.lblRent_Title.Size = new System.Drawing.Size(130, 24);
            this.lblRent_Title.TabIndex = 14;
            this.lblRent_Title.Text = "Rent Vehicle";
            // 
            // UCRent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.lblRent_Title);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnRent_AddClient);
            this.Controls.Add(this.btnRent_Confirm);
            this.Controls.Add(this.datetimeRent_ReturnDate);
            this.Controls.Add(this.datetimeRent_RentDate);
            this.Controls.Add(this.cbRent_SelectVehicle);
            this.Controls.Add(this.cbRent_SelectClient);
            this.Controls.Add(this.lblRent_EstimateCost);
            this.Controls.Add(this.lblRent_SelectVehicle);
            this.Controls.Add(this.lblRent_ReturnDate);
            this.Controls.Add(this.lblRent_RentDate);
            this.Controls.Add(this.lblRent_SelectClient);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "UCRent";
            this.Size = new System.Drawing.Size(1214, 486);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblRent_SelectClient;
        private System.Windows.Forms.Label lblRent_RentDate;
        private System.Windows.Forms.Label lblRent_ReturnDate;
        private System.Windows.Forms.Label lblRent_SelectVehicle;
        private System.Windows.Forms.Label lblRent_EstimateCost;
        private System.Windows.Forms.ComboBox cbRent_SelectClient;
        private System.Windows.Forms.ComboBox cbRent_SelectVehicle;
        private System.Windows.Forms.DateTimePicker datetimeRent_RentDate;
        private System.Windows.Forms.DateTimePicker datetimeRent_ReturnDate;
        private System.Windows.Forms.Button btnRent_Confirm;
        private System.Windows.Forms.Label lblRent_CostTotal;
        private System.Windows.Forms.Button btnRent_AddClient;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblRent_Title;
    }
}
