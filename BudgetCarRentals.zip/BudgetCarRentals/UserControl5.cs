﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace BudgetCarRentals
{
    public partial class ucAddVehicle : UserControl
    {
        SqlConnection con = new SqlConnection(@"Data Source=JEANDRE-PC;Initial Catalog=Budget_Car_Rental_Data;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        SqlCommand comm;
        SqlDataAdapter adapt;   //Creating database connection variable
        SqlDataReader reader;

        public ucAddVehicle()
        {
            InitializeComponent();
        }

        private void btnAddVehicle_Add_Click(object sender, EventArgs e)
        {
            con.Open();
            string make, model, reg;    //Creating variables for input
            int cost;
            int make_id = 0;
            int model_id = 0;
            int status = 1;

            make = cbAddVehicle_Make.Text;
            model = cbAddVehicle_Model.Text;    //Storing input in variables
            reg = txtAddVehicle_Registration.Text;
            int reg_length = reg.Length;


            if ((make != "") || (model != "") || (reg != "")) //Validation
            {
                if (reg_length == 8)
                {
                    if (int.TryParse(txtAddVehicle_Cost.Text, out cost)) //Validation
                    {
                        //======= Getting make ID from the make table ==============

                        string sql = $"SELECT Vehicle_Make_ID FROM Make WHERE Make_Description = '{make}'";
                        comm = new SqlCommand(sql, con);
                        adapt = new SqlDataAdapter();   //Creating new sql query
                        adapt.SelectCommand = comm;
                        reader = comm.ExecuteReader();

                        while (reader.Read())
                        {
                            make_id = (int)reader.GetValue(0);  //Getting make ID
                        }
                        reader.Close();

                        sql = $"SELECT Vehicle_Model_id FROM Model WHERE Model_Description = '{model}'";
                        comm = new SqlCommand(sql, con);
                        adapt = new SqlDataAdapter();   //Creating new sql query
                        adapt.SelectCommand = comm;
                        reader = comm.ExecuteReader();

                        while (reader.Read())
                        {
                            model_id = (int)reader.GetValue(0); //Getting model ID
                        }
                        reader.Close();

                        //=================Adding a new record to the table vehicle ========================

                        sql = $"INSERT INTO Vehicle(Vehicle_Make_ID, Vehicle_Model_id , Vehicle_Status, Registration , Cost ) VALUES({make_id}, {model_id}, {status}, '{reg}', {cost})";
                        comm = new SqlCommand(sql, con);
                        adapt = new SqlDataAdapter();   //Inserting data intto database
                        adapt.InsertCommand = comm;
                        adapt.InsertCommand.ExecuteNonQuery();

                        cbAddVehicle_Make.Text = "";
                        cbAddVehicle_Model.Text = "";
                        txtAddVehicle_Registration.Text = "";   //Clearing inputs
                        txtAddVehicle_Cost.Text = "";
                        cbAddVehicle_Model.Enabled = false;
                        MessageBox.Show("Vehicle added successfully!"); //Success message

                    }
                    else
                    {
                        MessageBox.Show("The registration number should contain 8 characters!");    //Error message
                    }
                }
                else
                {
                    MessageBox.Show("Registration number should be 8 characters!");
                }
            }
            else
            {
                MessageBox.Show("Invalid input!");  //Error Message
            }
            con.Close();
        }

        private void ucAddVehicle_Load(object sender, EventArgs e)
        {
            //======== Populating make combo boxes ===================

            con.Open();
            string sql = "SELECT DISTINCT Make_Description FROM Make";
            comm = new SqlCommand(sql, con);
            adapt = new SqlDataAdapter();   //Creating new SQL query
            adapt.SelectCommand = comm;
            reader = comm.ExecuteReader();

            while (reader.Read())
            {
                cbAddVehicle_Make.Items.Add(reader.GetValue(0));    //Populating combo box
            }
            reader.Close();

            con.Close();
        }

        private void cbAddVehicle_Make_SelectedIndexChanged(object sender, EventArgs e)
        {
            //================Populating the model combo box ===========================
            con.Open();
            cbAddVehicle_Model.Enabled = true;
            cbAddVehicle_Model.Items.Clear();
            string make = cbAddVehicle_Make.Text;
            int make_id = 0; ;
            string sql = $"SELECT Vehicle_Make_ID FROM Make WHERE Make_Description = '{make}'";
            comm = new SqlCommand(sql, con);
            adapt = new SqlDataAdapter();   //Creating new SQL query
            adapt.SelectCommand = comm;
            reader = comm.ExecuteReader();

            while (reader.Read())
            {
                make_id = (int)reader.GetValue(0);  
            }
            reader.Close();

            sql = $"SELECT DISTINCT Model_Description FROM Model WHERE Vehicle_Make_ID = {make_id}";
            comm = new SqlCommand(sql, con);
            adapt = new SqlDataAdapter();   //Creating new SQL query
            adapt.SelectCommand = comm;
            reader = comm.ExecuteReader();

            while (reader.Read())
            {
                cbAddVehicle_Model.Items.Add(reader.GetValue(0));   //Populating combo box
            }
            reader.Close();
            con.Close();
        }
    }
}
