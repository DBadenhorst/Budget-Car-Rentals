﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BudgetCarRentals
{
    public partial class UCReturn : UserControl
    {
        SqlConnection con = new SqlConnection(@"Data Source=JEANDRE-PC;Initial Catalog=Budget_Car_Rental_Data;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        SqlCommand comm;
        SqlDataReader reader;
        int vehicleID, rentedID;
        DateTime currentDate = DateTime.Now;
        decimal tCost;

        public UCReturn()
        {
            InitializeComponent();
        }

        private void CurrentRented()
        {
            //create sql
            string sql = "SELECT ci.Client_ID, ci.Client_FName, ci.Client_LName, ci.Contact_No ";
            sql += "FROM RENTED_VEHICLE_TRANSACTIONS rvt, VEHICLE v, CLIENT_INFORMATION ci ";
            sql += $"Where v.Vehicle_Status = 1 AND rvt.Vehicle_ID = v.Vehicle_ID AND rvt.Client_ID = ci.Client_ID ";
            sql += "ORDER BY rvt.Returned_Date";

            // execute sql
            con.Open();
            comm = new SqlCommand(sql, con);

            // read and display cutomers with current rented vehicles
            reader = comm.ExecuteReader();
            while (reader.Read())
            {
                int client_ID = (int)reader.GetValue(0);
                string fName = reader.GetString(1);
                string lName = reader.GetString(2);
                string number = reader.GetString(3);

                string output = client_ID.ToString() + ". " + fName + " " + lName + " (" + number + ")";
                cbSelectClient.Items.Add(output);
            }

            reader.Close();
            con.Close();
        }

        private void DefaultLabels()
        {
            // setting labels to default
            lblReturn_VehicleDetail.Text = "";
            lblReturn_RentDateDetail.Text = "";
            lblReturn_ReturnDateDetail.Text = "";
            lblReturn_CurrentDateDetail.Text = "";
            lblReturn_NotesDetails.Text = "";
            lblReturn_AdditionalCostDetail.Text = "";
            lblReturn_Due.Text = "";
        }

        private void cbSelectClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            decimal penaltyCost = 0;

            // enable button only after person was selected
            btnRent_Confirm.Enabled = true;

            // Create sql
            string sql = "SELECT ma.Make_description, mo.Model_Description, rvt.Rented_date, rvt.Returned_date, v.Cost, v.Vehicle_id, rvt.Rented_ID ";
            sql += "FROM RENTED_VEHICLE_TRANSACTIONS rvt, VEHICLE v, MODEL mo, MAKE ma, CLIENT_INFORMATION ci ";
            sql += $"Where ci.Client_ID = {cbSelectClient.SelectedItem.ToString().Substring(0, 1)} ";
            sql += "AND rvt.Client_ID = ci.Client_ID AND rvt.Vehicle_ID = v.Vehicle_ID AND v.Vehicle_Make_ID = ma.Vehicle_Make_ID AND v.Vehicle_Model_id = mo.Vehicle_Model_id";
            
            // execute sql
            con.Open();
            comm = new SqlCommand(sql, con);

            // setting data readable from tables
            reader = comm.ExecuteReader();
            reader.Read();

            // read data into needed variables
            string make = reader.GetString(0);
            string model = reader.GetString(1);
            DateTime rentedDate = (DateTime) reader.GetValue(2);
            DateTime returnDate = (DateTime) reader.GetValue(3);
            decimal costPerDay = (decimal) reader.GetValue(4);

            vehicleID = (int)reader.GetValue(5);
            rentedID = (int)reader.GetValue(6);
            con.Close();
            reader.Close();

            // setting label values
            lblReturn_VehicleDetail.Text = make + ", " + model;
            lblReturn_RentDateDetail.Text = rentedDate.ToString("dd MMMM yyyy");
            lblReturn_ReturnDateDetail.Text = returnDate.ToString("dd MMMM yyyy");
            lblReturn_CurrentDateDetail.Text = currentDate.ToString("dd MMMM yyyy");

            // check to see if the car was late and if so a penalty cost should be calculated
            if (currentDate != returnDate)
            {
                string daysLate = (DateTime.Now - returnDate).ToString("dd"); // calculte days late for penalty cost
                lblReturn_NotesDetails.Text = daysLate + " Days late";
            
                penaltyCost = costPerDay * (int.Parse(daysLate)); // calculate penalty cost
                lblReturn_AdditionalCostDetail.Text = penaltyCost.ToString("c2");
            }
            
            decimal cost = decimal.Parse((returnDate - rentedDate).ToString("dd")) * costPerDay;
            tCost = cost + penaltyCost;
            
            lblReturn_Due.Text = (tCost).ToString("c2");
        }

        private void UCReturn_Load(object sender, EventArgs e)
        {
            CurrentRented();
            DefaultLabels();
        }

        private void btnRent_Confirm_Click(object sender, EventArgs e)
        {
            // create update sql for vehicle returned
            string sql = "UPDATE VEHICLE ";
            sql += $"SET Vehicle_Status = 0 ";
            sql += $"WHERE Vehicle_ID = {vehicleID}";

            string sql1 = "UPDATE RENTED_VEHICLE_TRANSACTIONS ";
            sql1 += $"SET Returned_Date = '{currentDate.ToShortDateString()}', Cost = {tCost} ";
            sql1 += $"WHERE Rented_ID = {rentedID}";

            // execute sql
            con.Open();
            comm = new SqlCommand(sql1, con);
            comm.ExecuteNonQuery();
            comm = new SqlCommand(sql, con);
            comm.ExecuteNonQuery();
            con.Close();

            // indicate that vehicle has been returned in the database
            MessageBox.Show("Vehicle returned successful.");

            //resetting combobox
            cbSelectClient.Text = "";
            cbSelectClient.Items.Clear();
            CurrentRented();

            // resetting output labels
            DefaultLabels();
            btnRent_Confirm.Enabled = false;
        }
    }
}
