﻿namespace BudgetCarRentals
{
    partial class UCReturn
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblReturn_SelectClient = new System.Windows.Forms.Label();
            this.lblReturn_Report = new System.Windows.Forms.Label();
            this.lblReturn_TotalDue = new System.Windows.Forms.Label();
            this.cbSelectClient = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblReturn_CurrentDateDetail = new System.Windows.Forms.Label();
            this.lblReturn_CurrentDate = new System.Windows.Forms.Label();
            this.lblReturn_NotesDetails = new System.Windows.Forms.Label();
            this.lblReturn_AdditionalCostDetail = new System.Windows.Forms.Label();
            this.lblReturn_ReturnDateDetail = new System.Windows.Forms.Label();
            this.lblReturn_RentDateDetail = new System.Windows.Forms.Label();
            this.lblReturn_VehicleDetail = new System.Windows.Forms.Label();
            this.lblReturn_Notes = new System.Windows.Forms.Label();
            this.lblReturn_AdditionalCost = new System.Windows.Forms.Label();
            this.lblReturn_ReturnDate = new System.Windows.Forms.Label();
            this.lblReturn_RentDate = new System.Windows.Forms.Label();
            this.lblReturn_Vehicle = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblReturn_Due = new System.Windows.Forms.Label();
            this.lblReturn_Title = new System.Windows.Forms.Label();
            this.btnRent_Confirm = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblReturn_SelectClient
            // 
            this.lblReturn_SelectClient.AutoSize = true;
            this.lblReturn_SelectClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturn_SelectClient.ForeColor = System.Drawing.Color.White;
            this.lblReturn_SelectClient.Location = new System.Drawing.Point(115, 89);
            this.lblReturn_SelectClient.Name = "lblReturn_SelectClient";
            this.lblReturn_SelectClient.Size = new System.Drawing.Size(128, 25);
            this.lblReturn_SelectClient.TabIndex = 0;
            this.lblReturn_SelectClient.Text = "Select Client:";
            // 
            // lblReturn_Report
            // 
            this.lblReturn_Report.AutoSize = true;
            this.lblReturn_Report.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturn_Report.ForeColor = System.Drawing.Color.White;
            this.lblReturn_Report.Location = new System.Drawing.Point(693, 89);
            this.lblReturn_Report.Name = "lblReturn_Report";
            this.lblReturn_Report.Size = new System.Drawing.Size(75, 25);
            this.lblReturn_Report.TabIndex = 1;
            this.lblReturn_Report.Text = "Report:";
            // 
            // lblReturn_TotalDue
            // 
            this.lblReturn_TotalDue.AutoSize = true;
            this.lblReturn_TotalDue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturn_TotalDue.ForeColor = System.Drawing.Color.White;
            this.lblReturn_TotalDue.Location = new System.Drawing.Point(693, 455);
            this.lblReturn_TotalDue.Name = "lblReturn_TotalDue";
            this.lblReturn_TotalDue.Size = new System.Drawing.Size(100, 25);
            this.lblReturn_TotalDue.TabIndex = 2;
            this.lblReturn_TotalDue.Text = "Total due:";
            // 
            // cbSelectClient
            // 
            this.cbSelectClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbSelectClient.FormattingEnabled = true;
            this.cbSelectClient.Location = new System.Drawing.Point(119, 116);
            this.cbSelectClient.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbSelectClient.Name = "cbSelectClient";
            this.cbSelectClient.Size = new System.Drawing.Size(437, 33);
            this.cbSelectClient.TabIndex = 4;
            this.cbSelectClient.SelectedIndexChanged += new System.EventHandler(this.cbSelectClient_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DimGray;
            this.panel1.Controls.Add(this.lblReturn_CurrentDateDetail);
            this.panel1.Controls.Add(this.lblReturn_CurrentDate);
            this.panel1.Controls.Add(this.lblReturn_NotesDetails);
            this.panel1.Controls.Add(this.lblReturn_AdditionalCostDetail);
            this.panel1.Controls.Add(this.lblReturn_ReturnDateDetail);
            this.panel1.Controls.Add(this.lblReturn_RentDateDetail);
            this.panel1.Controls.Add(this.lblReturn_VehicleDetail);
            this.panel1.Controls.Add(this.lblReturn_Notes);
            this.panel1.Controls.Add(this.lblReturn_AdditionalCost);
            this.panel1.Controls.Add(this.lblReturn_ReturnDate);
            this.panel1.Controls.Add(this.lblReturn_RentDate);
            this.panel1.Controls.Add(this.lblReturn_Vehicle);
            this.panel1.Location = new System.Drawing.Point(699, 116);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(792, 270);
            this.panel1.TabIndex = 5;
            // 
            // lblReturn_CurrentDateDetail
            // 
            this.lblReturn_CurrentDateDetail.AutoSize = true;
            this.lblReturn_CurrentDateDetail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturn_CurrentDateDetail.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblReturn_CurrentDateDetail.Location = new System.Drawing.Point(480, 140);
            this.lblReturn_CurrentDateDetail.Name = "lblReturn_CurrentDateDetail";
            this.lblReturn_CurrentDateDetail.Size = new System.Drawing.Size(178, 25);
            this.lblReturn_CurrentDateDetail.TabIndex = 11;
            this.lblReturn_CurrentDateDetail.Text = "18 November 2022";
            // 
            // lblReturn_CurrentDate
            // 
            this.lblReturn_CurrentDate.AutoSize = true;
            this.lblReturn_CurrentDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturn_CurrentDate.Location = new System.Drawing.Point(35, 140);
            this.lblReturn_CurrentDate.Name = "lblReturn_CurrentDate";
            this.lblReturn_CurrentDate.Size = new System.Drawing.Size(129, 25);
            this.lblReturn_CurrentDate.TabIndex = 10;
            this.lblReturn_CurrentDate.Text = "Current Date:";
            // 
            // lblReturn_NotesDetails
            // 
            this.lblReturn_NotesDetails.AutoSize = true;
            this.lblReturn_NotesDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturn_NotesDetails.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblReturn_NotesDetails.Location = new System.Drawing.Point(480, 183);
            this.lblReturn_NotesDetails.Name = "lblReturn_NotesDetails";
            this.lblReturn_NotesDetails.Size = new System.Drawing.Size(106, 25);
            this.lblReturn_NotesDetails.TabIndex = 9;
            this.lblReturn_NotesDetails.Text = "3 days late";
            // 
            // lblReturn_AdditionalCostDetail
            // 
            this.lblReturn_AdditionalCostDetail.AutoSize = true;
            this.lblReturn_AdditionalCostDetail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturn_AdditionalCostDetail.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblReturn_AdditionalCostDetail.Location = new System.Drawing.Point(480, 228);
            this.lblReturn_AdditionalCostDetail.Name = "lblReturn_AdditionalCostDetail";
            this.lblReturn_AdditionalCostDetail.Size = new System.Drawing.Size(90, 25);
            this.lblReturn_AdditionalCostDetail.TabIndex = 8;
            this.lblReturn_AdditionalCostDetail.Text = "R 200.00";
            // 
            // lblReturn_ReturnDateDetail
            // 
            this.lblReturn_ReturnDateDetail.AutoSize = true;
            this.lblReturn_ReturnDateDetail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturn_ReturnDateDetail.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblReturn_ReturnDateDetail.Location = new System.Drawing.Point(480, 96);
            this.lblReturn_ReturnDateDetail.Name = "lblReturn_ReturnDateDetail";
            this.lblReturn_ReturnDateDetail.Size = new System.Drawing.Size(178, 25);
            this.lblReturn_ReturnDateDetail.TabIndex = 7;
            this.lblReturn_ReturnDateDetail.Text = "15 November 2022";
            // 
            // lblReturn_RentDateDetail
            // 
            this.lblReturn_RentDateDetail.AutoSize = true;
            this.lblReturn_RentDateDetail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturn_RentDateDetail.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblReturn_RentDateDetail.Location = new System.Drawing.Point(480, 52);
            this.lblReturn_RentDateDetail.Name = "lblReturn_RentDateDetail";
            this.lblReturn_RentDateDetail.Size = new System.Drawing.Size(178, 25);
            this.lblReturn_RentDateDetail.TabIndex = 6;
            this.lblReturn_RentDateDetail.Text = "11 November 2022";
            // 
            // lblReturn_VehicleDetail
            // 
            this.lblReturn_VehicleDetail.AutoSize = true;
            this.lblReturn_VehicleDetail.BackColor = System.Drawing.Color.DimGray;
            this.lblReturn_VehicleDetail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturn_VehicleDetail.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblReturn_VehicleDetail.Location = new System.Drawing.Point(480, 7);
            this.lblReturn_VehicleDetail.Name = "lblReturn_VehicleDetail";
            this.lblReturn_VehicleDetail.Size = new System.Drawing.Size(240, 25);
            this.lblReturn_VehicleDetail.TabIndex = 5;
            this.lblReturn_VehicleDetail.Text = "Toyoya, Hilux Double Cab";
            // 
            // lblReturn_Notes
            // 
            this.lblReturn_Notes.AutoSize = true;
            this.lblReturn_Notes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturn_Notes.Location = new System.Drawing.Point(35, 183);
            this.lblReturn_Notes.Name = "lblReturn_Notes";
            this.lblReturn_Notes.Size = new System.Drawing.Size(69, 25);
            this.lblReturn_Notes.TabIndex = 4;
            this.lblReturn_Notes.Text = "Notes:";
            // 
            // lblReturn_AdditionalCost
            // 
            this.lblReturn_AdditionalCost.AutoSize = true;
            this.lblReturn_AdditionalCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturn_AdditionalCost.Location = new System.Drawing.Point(35, 228);
            this.lblReturn_AdditionalCost.Name = "lblReturn_AdditionalCost";
            this.lblReturn_AdditionalCost.Size = new System.Drawing.Size(150, 25);
            this.lblReturn_AdditionalCost.TabIndex = 3;
            this.lblReturn_AdditionalCost.Text = "Additional Cost:";
            // 
            // lblReturn_ReturnDate
            // 
            this.lblReturn_ReturnDate.AutoSize = true;
            this.lblReturn_ReturnDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturn_ReturnDate.Location = new System.Drawing.Point(35, 96);
            this.lblReturn_ReturnDate.Name = "lblReturn_ReturnDate";
            this.lblReturn_ReturnDate.Size = new System.Drawing.Size(121, 25);
            this.lblReturn_ReturnDate.TabIndex = 2;
            this.lblReturn_ReturnDate.Text = "Return Date:";
            // 
            // lblReturn_RentDate
            // 
            this.lblReturn_RentDate.AutoSize = true;
            this.lblReturn_RentDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturn_RentDate.Location = new System.Drawing.Point(35, 52);
            this.lblReturn_RentDate.Name = "lblReturn_RentDate";
            this.lblReturn_RentDate.Size = new System.Drawing.Size(104, 25);
            this.lblReturn_RentDate.TabIndex = 1;
            this.lblReturn_RentDate.Text = "Rent Date:";
            // 
            // lblReturn_Vehicle
            // 
            this.lblReturn_Vehicle.AutoSize = true;
            this.lblReturn_Vehicle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturn_Vehicle.Location = new System.Drawing.Point(35, 7);
            this.lblReturn_Vehicle.Name = "lblReturn_Vehicle";
            this.lblReturn_Vehicle.Size = new System.Drawing.Size(83, 25);
            this.lblReturn_Vehicle.TabIndex = 0;
            this.lblReturn_Vehicle.Text = "Vehicle:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DimGray;
            this.panel2.Controls.Add(this.lblReturn_Due);
            this.panel2.Location = new System.Drawing.Point(699, 482);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 100);
            this.panel2.TabIndex = 6;
            // 
            // lblReturn_Due
            // 
            this.lblReturn_Due.AutoSize = true;
            this.lblReturn_Due.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturn_Due.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblReturn_Due.Location = new System.Drawing.Point(45, 38);
            this.lblReturn_Due.Name = "lblReturn_Due";
            this.lblReturn_Due.Size = new System.Drawing.Size(101, 25);
            this.lblReturn_Due.TabIndex = 0;
            this.lblReturn_Due.Text = "R 1000.00";
            // 
            // lblReturn_Title
            // 
            this.lblReturn_Title.AutoSize = true;
            this.lblReturn_Title.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturn_Title.ForeColor = System.Drawing.Color.White;
            this.lblReturn_Title.Location = new System.Drawing.Point(13, 14);
            this.lblReturn_Title.Name = "lblReturn_Title";
            this.lblReturn_Title.Size = new System.Drawing.Size(153, 25);
            this.lblReturn_Title.TabIndex = 7;
            this.lblReturn_Title.Text = "Return Vehicle";
            // 
            // btnRent_Confirm
            // 
            this.btnRent_Confirm.BackColor = System.Drawing.Color.DimGray;
            this.btnRent_Confirm.Enabled = false;
            this.btnRent_Confirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRent_Confirm.ForeColor = System.Drawing.Color.Black;
            this.btnRent_Confirm.Location = new System.Drawing.Point(1467, 544);
            this.btnRent_Confirm.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnRent_Confirm.Name = "btnRent_Confirm";
            this.btnRent_Confirm.Size = new System.Drawing.Size(148, 50);
            this.btnRent_Confirm.TabIndex = 11;
            this.btnRent_Confirm.Text = "Confirm";
            this.btnRent_Confirm.UseVisualStyleBackColor = false;
            this.btnRent_Confirm.Click += new System.EventHandler(this.btnRent_Confirm_Click);
            // 
            // UCReturn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.btnRent_Confirm);
            this.Controls.Add(this.lblReturn_Title);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.cbSelectClient);
            this.Controls.Add(this.lblReturn_TotalDue);
            this.Controls.Add(this.lblReturn_Report);
            this.Controls.Add(this.lblReturn_SelectClient);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "UCReturn";
            this.Size = new System.Drawing.Size(1619, 598);
            this.Load += new System.EventHandler(this.UCReturn_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblReturn_SelectClient;
        private System.Windows.Forms.Label lblReturn_Report;
        private System.Windows.Forms.Label lblReturn_TotalDue;
        private System.Windows.Forms.ComboBox cbSelectClient;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblReturn_Due;
        private System.Windows.Forms.Label lblReturn_NotesDetails;
        private System.Windows.Forms.Label lblReturn_AdditionalCostDetail;
        private System.Windows.Forms.Label lblReturn_ReturnDateDetail;
        private System.Windows.Forms.Label lblReturn_RentDateDetail;
        private System.Windows.Forms.Label lblReturn_VehicleDetail;
        private System.Windows.Forms.Label lblReturn_Notes;
        private System.Windows.Forms.Label lblReturn_AdditionalCost;
        private System.Windows.Forms.Label lblReturn_ReturnDate;
        private System.Windows.Forms.Label lblReturn_RentDate;
        private System.Windows.Forms.Label lblReturn_Vehicle;
        private System.Windows.Forms.Label lblReturn_Title;
        private System.Windows.Forms.Button btnRent_Confirm;
        private System.Windows.Forms.Label lblReturn_CurrentDateDetail;
        private System.Windows.Forms.Label lblReturn_CurrentDate;
    }
}
