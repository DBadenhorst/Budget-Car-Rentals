﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Windows.Forms.VisualStyles;

namespace BudgetCarRentals
{
    public partial class ucAddMakeModel : UserControl
    {
        SqlConnection conn = new SqlConnection(@"Data Source=JEANDRE-PC;Initial Catalog=Budget_Car_Rental_Data;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        SqlCommand comm;
        SqlDataAdapter adapt;
        SqlDataReader reader;

        public ucAddMakeModel()
        {
            InitializeComponent();
        }

        private void btnAddMakeModel_AddMake_Click(object sender, EventArgs e)
        {
            string make = txtAddMakeModel_MakeDetail.Text;
            if (txtAddMakeModel_MakeDetail.Text != "" || txtAddMakeModel_MakeDetail.Text == " ")
            {
                conn.Open();
                string sql = $"Insert Into MAKE (Make_Description) Values ('{make}')";
                comm = new SqlCommand(sql, conn);
                comm.ExecuteNonQuery();
                MessageBox.Show("Record was added");
                conn.Close();
                txtAddMakeModel_MakeDetail.Clear();
                cbAddMakeModel_Make.Items.Clear();

                conn.Open();
                sql = "SELECT DISTINCT Make_Description FROM Make";
                comm = new SqlCommand(sql, conn);
                adapt = new SqlDataAdapter();
                adapt.SelectCommand = comm;
                reader = comm.ExecuteReader();

                make = "";
                while (reader.Read())
                {
                    make = reader.GetString(0);
                    cbAddMakeModel_Make.Items.Add(make);
                }
                reader.Close();
                conn.Close();
            }
            else
            {
                txtAddMakeModel_MakeDetail.Clear();
                txtAddMakeModel_MakeDetail.Focus();
            }
        }

        private void btnAddMakeModel_AddModel_Click(object sender, EventArgs e)
        {
            conn.Open();
            string model = txtAddMakeModel_Model.Text;
            string make = cbAddMakeModel_Make.Text;
            int make_id = 0;
            if (txtAddMakeModel_Model.Text != "" || txtAddMakeModel_Model.Text == " ")
            {
                string sql = $"Select Vehicle_Make_ID FROM Make WHERE Make_Description = '{make}'";
                comm = new SqlCommand(sql, conn);
                adapt = new SqlDataAdapter();
                adapt.SelectCommand = comm;
                reader = comm.ExecuteReader();

                while (reader.Read())
                {
                    make_id = (int)reader.GetValue(0);
                }
                reader.Close();

                sql = $"Insert Into MODEL (Model_Description, Vehicle_Make_ID) Values ('{model}', {make_id})";
                comm = new SqlCommand(sql, conn);
                adapt = new SqlDataAdapter();
                adapt.InsertCommand = comm;
                adapt.InsertCommand.ExecuteNonQuery();

                MessageBox.Show("Record was added");
                conn.Close();
                txtAddMakeModel_Model.Clear();
                cbAddMakeModel_Make.Text = "";
            }
            else
            {
                txtAddMakeModel_Model.Clear();
                txtAddMakeModel_Model.Focus();
                cbAddMakeModel_Make.Text = "";
            }
        }

        private void cbAddMakeModel_Make_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void txtAddMakeModel_Model_TextChanged(object sender, EventArgs e)
        {

        }

        private void ucAddMakeModel_Load(object sender, EventArgs e)
        {
            conn.Open();
            string sql = "Select DISTINCT Make_Description FROM Make";
            comm = new SqlCommand(sql, conn);
            adapt = new SqlDataAdapter();
            adapt.SelectCommand = comm;
            reader = comm.ExecuteReader();
            while (reader.Read())
            {
                cbAddMakeModel_Make.Items.Add(reader.GetValue(0));
            }
            reader.Close();
            conn.Close();
        }
    }
}
