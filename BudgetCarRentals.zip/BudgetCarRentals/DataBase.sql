DROP DATABASE IF EXISTS Budget_Car_Rental_Data;
GO
CREATE DATABASE Budget_Car_Rental_Data;
GO