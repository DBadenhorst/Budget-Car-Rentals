﻿namespace BudgetCarRentals
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.rentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.returnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clientsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addClientToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateClientToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vehiclesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addVehicleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateVehicleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.makeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addMakeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateMakeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ucUpdateDeleteClient1 = new BudgetCarRentals.ucUpdateDeleteClient();
            this.ucAddClient1 = new BudgetCarRentals.ucAddClient();
            this.ucReturn1 = new BudgetCarRentals.UCReturn();
            this.ucRent1 = new BudgetCarRentals.UCRent();
            this.ucAddVehicle1 = new BudgetCarRentals.ucAddVehicle();
            this.ucUpdateDeleteVehicle1 = new BudgetCarRentals.ucUpdateDeleteVehicle();
            this.ucAddMakeModel1 = new BudgetCarRentals.ucAddMakeModel();
            this.ucUpdateDeleteMakeModel1 = new BudgetCarRentals.ucUpdateDeleteMakeModel();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.menuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rentToolStripMenuItem,
            this.returnToolStripMenuItem,
            this.clientsToolStripMenuItem,
            this.vehiclesToolStripMenuItem,
            this.makeToolStripMenuItem,
            this.reportToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(131, 152);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(559, 36);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // rentToolStripMenuItem
            // 
            this.rentToolStripMenuItem.Name = "rentToolStripMenuItem";
            this.rentToolStripMenuItem.Size = new System.Drawing.Size(65, 32);
            this.rentToolStripMenuItem.Text = "Rent";
            this.rentToolStripMenuItem.Click += new System.EventHandler(this.rentToolStripMenuItem_Click);
            // 
            // returnToolStripMenuItem
            // 
            this.returnToolStripMenuItem.Name = "returnToolStripMenuItem";
            this.returnToolStripMenuItem.Size = new System.Drawing.Size(83, 32);
            this.returnToolStripMenuItem.Text = "Return";
            this.returnToolStripMenuItem.Click += new System.EventHandler(this.returnToolStripMenuItem_Click);
            // 
            // clientsToolStripMenuItem
            // 
            this.clientsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addClientToolStripMenuItem,
            this.updateClientToolStripMenuItem});
            this.clientsToolStripMenuItem.Name = "clientsToolStripMenuItem";
            this.clientsToolStripMenuItem.Size = new System.Drawing.Size(84, 32);
            this.clientsToolStripMenuItem.Text = "Clients";
            // 
            // addClientToolStripMenuItem
            // 
            this.addClientToolStripMenuItem.Name = "addClientToolStripMenuItem";
            this.addClientToolStripMenuItem.Size = new System.Drawing.Size(282, 32);
            this.addClientToolStripMenuItem.Text = "Add Client";
            this.addClientToolStripMenuItem.Click += new System.EventHandler(this.addClientToolStripMenuItem_Click);
            // 
            // updateClientToolStripMenuItem
            // 
            this.updateClientToolStripMenuItem.Name = "updateClientToolStripMenuItem";
            this.updateClientToolStripMenuItem.Size = new System.Drawing.Size(282, 32);
            this.updateClientToolStripMenuItem.Text = "Update/Delete Client";
            this.updateClientToolStripMenuItem.Click += new System.EventHandler(this.updateClientToolStripMenuItem_Click);
            // 
            // vehiclesToolStripMenuItem
            // 
            this.vehiclesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addVehicleToolStripMenuItem,
            this.updateVehicleToolStripMenuItem});
            this.vehiclesToolStripMenuItem.Name = "vehiclesToolStripMenuItem";
            this.vehiclesToolStripMenuItem.Size = new System.Drawing.Size(95, 32);
            this.vehiclesToolStripMenuItem.Text = "Vehicles";
            // 
            // addVehicleToolStripMenuItem
            // 
            this.addVehicleToolStripMenuItem.Name = "addVehicleToolStripMenuItem";
            this.addVehicleToolStripMenuItem.Size = new System.Drawing.Size(293, 32);
            this.addVehicleToolStripMenuItem.Text = "Add Vehicle";
            this.addVehicleToolStripMenuItem.Click += new System.EventHandler(this.addVehicleToolStripMenuItem_Click);
            // 
            // updateVehicleToolStripMenuItem
            // 
            this.updateVehicleToolStripMenuItem.Name = "updateVehicleToolStripMenuItem";
            this.updateVehicleToolStripMenuItem.Size = new System.Drawing.Size(293, 32);
            this.updateVehicleToolStripMenuItem.Text = "Update/Delete Vehicle";
            this.updateVehicleToolStripMenuItem.Click += new System.EventHandler(this.updateVehicleToolStripMenuItem_Click);
            // 
            // makeToolStripMenuItem
            // 
            this.makeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addMakeToolStripMenuItem,
            this.updateMakeToolStripMenuItem});
            this.makeToolStripMenuItem.Name = "makeToolStripMenuItem";
            this.makeToolStripMenuItem.Size = new System.Drawing.Size(139, 32);
            this.makeToolStripMenuItem.Text = "Make/Model";
            // 
            // addMakeToolStripMenuItem
            // 
            this.addMakeToolStripMenuItem.Name = "addMakeToolStripMenuItem";
            this.addMakeToolStripMenuItem.Size = new System.Drawing.Size(345, 32);
            this.addMakeToolStripMenuItem.Text = "Add Make/Model";
            this.addMakeToolStripMenuItem.Click += new System.EventHandler(this.addMakeToolStripMenuItem_Click);
            // 
            // updateMakeToolStripMenuItem
            // 
            this.updateMakeToolStripMenuItem.Name = "updateMakeToolStripMenuItem";
            this.updateMakeToolStripMenuItem.Size = new System.Drawing.Size(345, 32);
            this.updateMakeToolStripMenuItem.Text = "Update/Delete Make/Model";
            this.updateMakeToolStripMenuItem.Click += new System.EventHandler(this.updateMakeToolStripMenuItem_Click);
            // 
            // reportToolStripMenuItem
            // 
            this.reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            this.reportToolStripMenuItem.Size = new System.Drawing.Size(85, 32);
            this.reportToolStripMenuItem.Text = "Report";
            // 
            // ucUpdateDeleteClient1
            // 
            this.ucUpdateDeleteClient1.BackColor = System.Drawing.Color.Transparent;
            this.ucUpdateDeleteClient1.Location = new System.Drawing.Point(154, 210);
            this.ucUpdateDeleteClient1.Name = "ucUpdateDeleteClient1";
            this.ucUpdateDeleteClient1.Size = new System.Drawing.Size(1618, 598);
            this.ucUpdateDeleteClient1.TabIndex = 4;
            this.ucUpdateDeleteClient1.Visible = false;
            // 
            // ucAddClient1
            // 
            this.ucAddClient1.BackColor = System.Drawing.Color.Transparent;
            this.ucAddClient1.Location = new System.Drawing.Point(154, 210);
            this.ucAddClient1.Name = "ucAddClient1";
            this.ucAddClient1.Size = new System.Drawing.Size(1618, 598);
            this.ucAddClient1.TabIndex = 3;
            this.ucAddClient1.Visible = false;
            // 
            // ucReturn1
            // 
            this.ucReturn1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ucReturn1.BackColor = System.Drawing.Color.Transparent;
            this.ucReturn1.Location = new System.Drawing.Point(154, 210);
            this.ucReturn1.Name = "ucReturn1";
            this.ucReturn1.Size = new System.Drawing.Size(1618, 598);
            this.ucReturn1.TabIndex = 2;
            this.ucReturn1.Visible = false;
            // 
            // ucRent1
            // 
            this.ucRent1.BackColor = System.Drawing.Color.Transparent;
            this.ucRent1.Location = new System.Drawing.Point(154, 210);
            this.ucRent1.Name = "ucRent1";
            this.ucRent1.Size = new System.Drawing.Size(1618, 598);
            this.ucRent1.TabIndex = 1;
            // 
            // ucAddVehicle1
            // 
            this.ucAddVehicle1.BackColor = System.Drawing.Color.Transparent;
            this.ucAddVehicle1.Location = new System.Drawing.Point(154, 210);
            this.ucAddVehicle1.Name = "ucAddVehicle1";
            this.ucAddVehicle1.Size = new System.Drawing.Size(1618, 598);
            this.ucAddVehicle1.TabIndex = 5;
            this.ucAddVehicle1.Visible = false;
            // 
            // ucUpdateDeleteVehicle1
            // 
            this.ucUpdateDeleteVehicle1.BackColor = System.Drawing.Color.Transparent;
            this.ucUpdateDeleteVehicle1.Location = new System.Drawing.Point(141, 201);
            this.ucUpdateDeleteVehicle1.Name = "ucUpdateDeleteVehicle1";
            this.ucUpdateDeleteVehicle1.Size = new System.Drawing.Size(1618, 598);
            this.ucUpdateDeleteVehicle1.TabIndex = 6;
            this.ucUpdateDeleteVehicle1.Visible = false;
            // 
            // ucAddMakeModel1
            // 
            this.ucAddMakeModel1.BackColor = System.Drawing.Color.Transparent;
            this.ucAddMakeModel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ucAddMakeModel1.ForeColor = System.Drawing.Color.White;
            this.ucAddMakeModel1.Location = new System.Drawing.Point(154, 210);
            this.ucAddMakeModel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ucAddMakeModel1.Name = "ucAddMakeModel1";
            this.ucAddMakeModel1.Size = new System.Drawing.Size(1618, 598);
            this.ucAddMakeModel1.TabIndex = 7;
            this.ucAddMakeModel1.Visible = false;
            // 
            // ucUpdateDeleteMakeModel1
            // 
            this.ucUpdateDeleteMakeModel1.BackColor = System.Drawing.Color.Transparent;
            this.ucUpdateDeleteMakeModel1.Location = new System.Drawing.Point(154, 210);
            this.ucUpdateDeleteMakeModel1.Name = "ucUpdateDeleteMakeModel1";
            this.ucUpdateDeleteMakeModel1.Size = new System.Drawing.Size(1618, 598);
            this.ucUpdateDeleteMakeModel1.TabIndex = 8;
            this.ucUpdateDeleteMakeModel1.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1924, 861);
            this.Controls.Add(this.ucUpdateDeleteMakeModel1);
            this.Controls.Add(this.ucAddMakeModel1);
            this.Controls.Add(this.ucUpdateDeleteVehicle1);
            this.Controls.Add(this.ucAddVehicle1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.ucUpdateDeleteClient1);
            this.Controls.Add(this.ucAddClient1);
            this.Controls.Add(this.ucReturn1);
            this.Controls.Add(this.ucRent1);
            this.Name = "Form1";
            this.Text = "Budget Car Rentals";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem rentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem returnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clientsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addClientToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateClientToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vehiclesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addVehicleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateVehicleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem makeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addMakeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateMakeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportToolStripMenuItem;
        private UCRent ucRent1;
        private UCReturn ucReturn1;
        private ucAddClient ucAddClient1;
        private ucUpdateDeleteClient ucUpdateDeleteClient1;
        private ucAddVehicle ucAddVehicle1;
        private ucUpdateDeleteVehicle ucUpdateDeleteVehicle1;
        private ucAddMakeModel ucAddMakeModel1;
        private ucUpdateDeleteMakeModel ucUpdateDeleteMakeModel1;
    }
}

