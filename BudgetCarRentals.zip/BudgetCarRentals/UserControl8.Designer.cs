﻿namespace BudgetCarRentals
{
    partial class ucUpdateDeleteMakeModel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtUpdateDeleteMakeModel_MakeMake = new System.Windows.Forms.TextBox();
            this.cbUpdateDeleteMakeModel_MakeSelectMake = new System.Windows.Forms.ComboBox();
            this.lblUpdateDeleteMakeModel_MakeMake = new System.Windows.Forms.Label();
            this.lblUpdateDeleteMakeModel_SelectMake = new System.Windows.Forms.Label();
            this.btnUpdateDeleteMakeModel_UpdateMake = new System.Windows.Forms.Button();
            this.btnUpdateDeleteMakeModel_DeleteMake = new System.Windows.Forms.Button();
            this.lblUpdateDeleteMakeModel_TitleMake = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cbUpdateDeleteMakeModel_ModelMake = new System.Windows.Forms.ComboBox();
            this.lblUpdateDeleteMakeModel_ModelSelectMake = new System.Windows.Forms.Label();
            this.txtUpdateDeleteMakeModel_ModelModel = new System.Windows.Forms.TextBox();
            this.txtUpdateDeleteMakeModel_ModelMake = new System.Windows.Forms.TextBox();
            this.lblUpdateDeleteMakeModel_ModelModel = new System.Windows.Forms.Label();
            this.lblUpdateDeleteMakeModel_ModelMake = new System.Windows.Forms.Label();
            this.cbUpdateDeleteMakeModel_ModelModel = new System.Windows.Forms.ComboBox();
            this.lblUpdateDeleteMakeModel_ModelSelectModel = new System.Windows.Forms.Label();
            this.btnUpdateDeleteMakeModel_UpdateModel = new System.Windows.Forms.Button();
            this.btnUpdateDeleteMakeModel_DeleteModel = new System.Windows.Forms.Button();
            this.lblUpdateDeleteMakeModel_TitleModel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.txtUpdateDeleteMakeModel_MakeMake);
            this.panel1.Controls.Add(this.cbUpdateDeleteMakeModel_MakeSelectMake);
            this.panel1.Controls.Add(this.lblUpdateDeleteMakeModel_MakeMake);
            this.panel1.Controls.Add(this.lblUpdateDeleteMakeModel_SelectMake);
            this.panel1.Controls.Add(this.btnUpdateDeleteMakeModel_UpdateMake);
            this.panel1.Controls.Add(this.btnUpdateDeleteMakeModel_DeleteMake);
            this.panel1.Controls.Add(this.lblUpdateDeleteMakeModel_TitleMake);
            this.panel1.Location = new System.Drawing.Point(290, 156);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(534, 397);
            this.panel1.TabIndex = 13;
            // 
            // txtUpdateDeleteMakeModel_MakeMake
            // 
            this.txtUpdateDeleteMakeModel_MakeMake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUpdateDeleteMakeModel_MakeMake.Location = new System.Drawing.Point(12, 166);
            this.txtUpdateDeleteMakeModel_MakeMake.Name = "txtUpdateDeleteMakeModel_MakeMake";
            this.txtUpdateDeleteMakeModel_MakeMake.Size = new System.Drawing.Size(340, 30);
            this.txtUpdateDeleteMakeModel_MakeMake.TabIndex = 13;
            // 
            // cbUpdateDeleteMakeModel_MakeSelectMake
            // 
            this.cbUpdateDeleteMakeModel_MakeSelectMake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbUpdateDeleteMakeModel_MakeSelectMake.FormattingEnabled = true;
            this.cbUpdateDeleteMakeModel_MakeSelectMake.Location = new System.Drawing.Point(9, 78);
            this.cbUpdateDeleteMakeModel_MakeSelectMake.Name = "cbUpdateDeleteMakeModel_MakeSelectMake";
            this.cbUpdateDeleteMakeModel_MakeSelectMake.Size = new System.Drawing.Size(343, 33);
            this.cbUpdateDeleteMakeModel_MakeSelectMake.TabIndex = 12;
            this.cbUpdateDeleteMakeModel_MakeSelectMake.SelectedIndexChanged += new System.EventHandler(this.cbUpdateDeleteMakeModel_MakeSelectMake_SelectedIndexChanged);
            // 
            // lblUpdateDeleteMakeModel_MakeMake
            // 
            this.lblUpdateDeleteMakeModel_MakeMake.AutoSize = true;
            this.lblUpdateDeleteMakeModel_MakeMake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateDeleteMakeModel_MakeMake.ForeColor = System.Drawing.Color.White;
            this.lblUpdateDeleteMakeModel_MakeMake.Location = new System.Drawing.Point(9, 138);
            this.lblUpdateDeleteMakeModel_MakeMake.Name = "lblUpdateDeleteMakeModel_MakeMake";
            this.lblUpdateDeleteMakeModel_MakeMake.Size = new System.Drawing.Size(67, 25);
            this.lblUpdateDeleteMakeModel_MakeMake.TabIndex = 11;
            this.lblUpdateDeleteMakeModel_MakeMake.Text = "Make:";
            // 
            // lblUpdateDeleteMakeModel_SelectMake
            // 
            this.lblUpdateDeleteMakeModel_SelectMake.AutoSize = true;
            this.lblUpdateDeleteMakeModel_SelectMake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateDeleteMakeModel_SelectMake.ForeColor = System.Drawing.Color.White;
            this.lblUpdateDeleteMakeModel_SelectMake.Location = new System.Drawing.Point(9, 50);
            this.lblUpdateDeleteMakeModel_SelectMake.Name = "lblUpdateDeleteMakeModel_SelectMake";
            this.lblUpdateDeleteMakeModel_SelectMake.Size = new System.Drawing.Size(127, 25);
            this.lblUpdateDeleteMakeModel_SelectMake.TabIndex = 10;
            this.lblUpdateDeleteMakeModel_SelectMake.Text = "Select Make:";
            // 
            // btnUpdateDeleteMakeModel_UpdateMake
            // 
            this.btnUpdateDeleteMakeModel_UpdateMake.BackColor = System.Drawing.Color.DimGray;
            this.btnUpdateDeleteMakeModel_UpdateMake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateDeleteMakeModel_UpdateMake.ForeColor = System.Drawing.Color.Black;
            this.btnUpdateDeleteMakeModel_UpdateMake.Location = new System.Drawing.Point(252, 341);
            this.btnUpdateDeleteMakeModel_UpdateMake.Name = "btnUpdateDeleteMakeModel_UpdateMake";
            this.btnUpdateDeleteMakeModel_UpdateMake.Size = new System.Drawing.Size(132, 51);
            this.btnUpdateDeleteMakeModel_UpdateMake.TabIndex = 9;
            this.btnUpdateDeleteMakeModel_UpdateMake.Text = "Update";
            this.btnUpdateDeleteMakeModel_UpdateMake.UseVisualStyleBackColor = false;
            this.btnUpdateDeleteMakeModel_UpdateMake.Click += new System.EventHandler(this.btnUpdateDeleteMakeModel_UpdateMake_Click);
            // 
            // btnUpdateDeleteMakeModel_DeleteMake
            // 
            this.btnUpdateDeleteMakeModel_DeleteMake.BackColor = System.Drawing.Color.DimGray;
            this.btnUpdateDeleteMakeModel_DeleteMake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateDeleteMakeModel_DeleteMake.ForeColor = System.Drawing.Color.Black;
            this.btnUpdateDeleteMakeModel_DeleteMake.Location = new System.Drawing.Point(401, 341);
            this.btnUpdateDeleteMakeModel_DeleteMake.Name = "btnUpdateDeleteMakeModel_DeleteMake";
            this.btnUpdateDeleteMakeModel_DeleteMake.Size = new System.Drawing.Size(132, 51);
            this.btnUpdateDeleteMakeModel_DeleteMake.TabIndex = 8;
            this.btnUpdateDeleteMakeModel_DeleteMake.Text = "Delete";
            this.btnUpdateDeleteMakeModel_DeleteMake.UseVisualStyleBackColor = false;
            this.btnUpdateDeleteMakeModel_DeleteMake.Click += new System.EventHandler(this.btnUpdateDeleteMakeModel_DeleteMake_Click);
            // 
            // lblUpdateDeleteMakeModel_TitleMake
            // 
            this.lblUpdateDeleteMakeModel_TitleMake.AutoSize = true;
            this.lblUpdateDeleteMakeModel_TitleMake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateDeleteMakeModel_TitleMake.ForeColor = System.Drawing.Color.White;
            this.lblUpdateDeleteMakeModel_TitleMake.Location = new System.Drawing.Point(4, 0);
            this.lblUpdateDeleteMakeModel_TitleMake.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUpdateDeleteMakeModel_TitleMake.Name = "lblUpdateDeleteMakeModel_TitleMake";
            this.lblUpdateDeleteMakeModel_TitleMake.Size = new System.Drawing.Size(72, 25);
            this.lblUpdateDeleteMakeModel_TitleMake.TabIndex = 0;
            this.lblUpdateDeleteMakeModel_TitleMake.Text = "Make:";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.cbUpdateDeleteMakeModel_ModelMake);
            this.panel2.Controls.Add(this.lblUpdateDeleteMakeModel_ModelSelectMake);
            this.panel2.Controls.Add(this.txtUpdateDeleteMakeModel_ModelModel);
            this.panel2.Controls.Add(this.txtUpdateDeleteMakeModel_ModelMake);
            this.panel2.Controls.Add(this.lblUpdateDeleteMakeModel_ModelModel);
            this.panel2.Controls.Add(this.lblUpdateDeleteMakeModel_ModelMake);
            this.panel2.Controls.Add(this.cbUpdateDeleteMakeModel_ModelModel);
            this.panel2.Controls.Add(this.lblUpdateDeleteMakeModel_ModelSelectModel);
            this.panel2.Controls.Add(this.btnUpdateDeleteMakeModel_UpdateModel);
            this.panel2.Controls.Add(this.btnUpdateDeleteMakeModel_DeleteModel);
            this.panel2.Controls.Add(this.lblUpdateDeleteMakeModel_TitleModel);
            this.panel2.Location = new System.Drawing.Point(847, 155);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(534, 397);
            this.panel2.TabIndex = 14;
            // 
            // cbUpdateDeleteMakeModel_ModelMake
            // 
            this.cbUpdateDeleteMakeModel_ModelMake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbUpdateDeleteMakeModel_ModelMake.FormattingEnabled = true;
            this.cbUpdateDeleteMakeModel_ModelMake.Location = new System.Drawing.Point(8, 66);
            this.cbUpdateDeleteMakeModel_ModelMake.Name = "cbUpdateDeleteMakeModel_ModelMake";
            this.cbUpdateDeleteMakeModel_ModelMake.Size = new System.Drawing.Size(343, 33);
            this.cbUpdateDeleteMakeModel_ModelMake.TabIndex = 14;
            this.cbUpdateDeleteMakeModel_ModelMake.SelectedIndexChanged += new System.EventHandler(this.cbUpdateDeleteMakeModel_ModelMake_SelectedIndexChanged);
            // 
            // lblUpdateDeleteMakeModel_ModelSelectMake
            // 
            this.lblUpdateDeleteMakeModel_ModelSelectMake.AutoSize = true;
            this.lblUpdateDeleteMakeModel_ModelSelectMake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateDeleteMakeModel_ModelSelectMake.ForeColor = System.Drawing.Color.White;
            this.lblUpdateDeleteMakeModel_ModelSelectMake.Location = new System.Drawing.Point(3, 38);
            this.lblUpdateDeleteMakeModel_ModelSelectMake.Name = "lblUpdateDeleteMakeModel_ModelSelectMake";
            this.lblUpdateDeleteMakeModel_ModelSelectMake.Size = new System.Drawing.Size(127, 25);
            this.lblUpdateDeleteMakeModel_ModelSelectMake.TabIndex = 17;
            this.lblUpdateDeleteMakeModel_ModelSelectMake.Text = "Select Make:";
            // 
            // txtUpdateDeleteMakeModel_ModelModel
            // 
            this.txtUpdateDeleteMakeModel_ModelModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUpdateDeleteMakeModel_ModelModel.Location = new System.Drawing.Point(9, 298);
            this.txtUpdateDeleteMakeModel_ModelModel.Name = "txtUpdateDeleteMakeModel_ModelModel";
            this.txtUpdateDeleteMakeModel_ModelModel.Size = new System.Drawing.Size(342, 30);
            this.txtUpdateDeleteMakeModel_ModelModel.TabIndex = 16;
            // 
            // txtUpdateDeleteMakeModel_ModelMake
            // 
            this.txtUpdateDeleteMakeModel_ModelMake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUpdateDeleteMakeModel_ModelMake.Location = new System.Drawing.Point(8, 220);
            this.txtUpdateDeleteMakeModel_ModelMake.Name = "txtUpdateDeleteMakeModel_ModelMake";
            this.txtUpdateDeleteMakeModel_ModelMake.Size = new System.Drawing.Size(343, 30);
            this.txtUpdateDeleteMakeModel_ModelMake.TabIndex = 15;
            // 
            // lblUpdateDeleteMakeModel_ModelModel
            // 
            this.lblUpdateDeleteMakeModel_ModelModel.AutoSize = true;
            this.lblUpdateDeleteMakeModel_ModelModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateDeleteMakeModel_ModelModel.ForeColor = System.Drawing.Color.White;
            this.lblUpdateDeleteMakeModel_ModelModel.Location = new System.Drawing.Point(7, 270);
            this.lblUpdateDeleteMakeModel_ModelModel.Name = "lblUpdateDeleteMakeModel_ModelModel";
            this.lblUpdateDeleteMakeModel_ModelModel.Size = new System.Drawing.Size(72, 25);
            this.lblUpdateDeleteMakeModel_ModelModel.TabIndex = 14;
            this.lblUpdateDeleteMakeModel_ModelModel.Text = "Model:";
            // 
            // lblUpdateDeleteMakeModel_ModelMake
            // 
            this.lblUpdateDeleteMakeModel_ModelMake.AutoSize = true;
            this.lblUpdateDeleteMakeModel_ModelMake.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateDeleteMakeModel_ModelMake.ForeColor = System.Drawing.Color.White;
            this.lblUpdateDeleteMakeModel_ModelMake.Location = new System.Drawing.Point(4, 192);
            this.lblUpdateDeleteMakeModel_ModelMake.Name = "lblUpdateDeleteMakeModel_ModelMake";
            this.lblUpdateDeleteMakeModel_ModelMake.Size = new System.Drawing.Size(67, 25);
            this.lblUpdateDeleteMakeModel_ModelMake.TabIndex = 13;
            this.lblUpdateDeleteMakeModel_ModelMake.Text = "Make:";
            // 
            // cbUpdateDeleteMakeModel_ModelModel
            // 
            this.cbUpdateDeleteMakeModel_ModelModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbUpdateDeleteMakeModel_ModelModel.FormattingEnabled = true;
            this.cbUpdateDeleteMakeModel_ModelModel.Location = new System.Drawing.Point(8, 142);
            this.cbUpdateDeleteMakeModel_ModelModel.Name = "cbUpdateDeleteMakeModel_ModelModel";
            this.cbUpdateDeleteMakeModel_ModelModel.Size = new System.Drawing.Size(343, 33);
            this.cbUpdateDeleteMakeModel_ModelModel.TabIndex = 12;
            this.cbUpdateDeleteMakeModel_ModelModel.SelectedIndexChanged += new System.EventHandler(this.cbUpdateDeleteMakeModel_ModelModel_SelectedIndexChanged);
            // 
            // lblUpdateDeleteMakeModel_ModelSelectModel
            // 
            this.lblUpdateDeleteMakeModel_ModelSelectModel.AutoSize = true;
            this.lblUpdateDeleteMakeModel_ModelSelectModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateDeleteMakeModel_ModelSelectModel.ForeColor = System.Drawing.Color.White;
            this.lblUpdateDeleteMakeModel_ModelSelectModel.Location = new System.Drawing.Point(4, 114);
            this.lblUpdateDeleteMakeModel_ModelSelectModel.Name = "lblUpdateDeleteMakeModel_ModelSelectModel";
            this.lblUpdateDeleteMakeModel_ModelSelectModel.Size = new System.Drawing.Size(132, 25);
            this.lblUpdateDeleteMakeModel_ModelSelectModel.TabIndex = 11;
            this.lblUpdateDeleteMakeModel_ModelSelectModel.Text = "Select Model:";
            // 
            // btnUpdateDeleteMakeModel_UpdateModel
            // 
            this.btnUpdateDeleteMakeModel_UpdateModel.BackColor = System.Drawing.Color.DimGray;
            this.btnUpdateDeleteMakeModel_UpdateModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateDeleteMakeModel_UpdateModel.ForeColor = System.Drawing.Color.Black;
            this.btnUpdateDeleteMakeModel_UpdateModel.Location = new System.Drawing.Point(263, 341);
            this.btnUpdateDeleteMakeModel_UpdateModel.Name = "btnUpdateDeleteMakeModel_UpdateModel";
            this.btnUpdateDeleteMakeModel_UpdateModel.Size = new System.Drawing.Size(132, 51);
            this.btnUpdateDeleteMakeModel_UpdateModel.TabIndex = 10;
            this.btnUpdateDeleteMakeModel_UpdateModel.Text = "Update";
            this.btnUpdateDeleteMakeModel_UpdateModel.UseVisualStyleBackColor = false;
            this.btnUpdateDeleteMakeModel_UpdateModel.Click += new System.EventHandler(this.btnUpdateDeleteMakeModel_UpdateModel_Click);
            // 
            // btnUpdateDeleteMakeModel_DeleteModel
            // 
            this.btnUpdateDeleteMakeModel_DeleteModel.BackColor = System.Drawing.Color.DimGray;
            this.btnUpdateDeleteMakeModel_DeleteModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateDeleteMakeModel_DeleteModel.ForeColor = System.Drawing.Color.Black;
            this.btnUpdateDeleteMakeModel_DeleteModel.Location = new System.Drawing.Point(401, 341);
            this.btnUpdateDeleteMakeModel_DeleteModel.Name = "btnUpdateDeleteMakeModel_DeleteModel";
            this.btnUpdateDeleteMakeModel_DeleteModel.Size = new System.Drawing.Size(132, 51);
            this.btnUpdateDeleteMakeModel_DeleteModel.TabIndex = 8;
            this.btnUpdateDeleteMakeModel_DeleteModel.Text = "Delete";
            this.btnUpdateDeleteMakeModel_DeleteModel.UseVisualStyleBackColor = false;
            this.btnUpdateDeleteMakeModel_DeleteModel.Click += new System.EventHandler(this.btnUpdateDeleteMakeModel_DeleteModel_Click);
            // 
            // lblUpdateDeleteMakeModel_TitleModel
            // 
            this.lblUpdateDeleteMakeModel_TitleModel.AutoSize = true;
            this.lblUpdateDeleteMakeModel_TitleModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateDeleteMakeModel_TitleModel.ForeColor = System.Drawing.Color.White;
            this.lblUpdateDeleteMakeModel_TitleModel.Location = new System.Drawing.Point(4, 0);
            this.lblUpdateDeleteMakeModel_TitleModel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUpdateDeleteMakeModel_TitleModel.Name = "lblUpdateDeleteMakeModel_TitleModel";
            this.lblUpdateDeleteMakeModel_TitleModel.Size = new System.Drawing.Size(78, 25);
            this.lblUpdateDeleteMakeModel_TitleModel.TabIndex = 0;
            this.lblUpdateDeleteMakeModel_TitleModel.Text = "Model:";
            // 
            // ucUpdateDeleteMakeModel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "ucUpdateDeleteMakeModel";
            this.Size = new System.Drawing.Size(1618, 598);
            this.Load += new System.EventHandler(this.ucUpdateDeleteMakeModel_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnUpdateDeleteMakeModel_UpdateMake;
        private System.Windows.Forms.Button btnUpdateDeleteMakeModel_DeleteMake;
        private System.Windows.Forms.Label lblUpdateDeleteMakeModel_TitleMake;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnUpdateDeleteMakeModel_UpdateModel;
        private System.Windows.Forms.Button btnUpdateDeleteMakeModel_DeleteModel;
        private System.Windows.Forms.Label lblUpdateDeleteMakeModel_TitleModel;
        private System.Windows.Forms.TextBox txtUpdateDeleteMakeModel_MakeMake;
        private System.Windows.Forms.ComboBox cbUpdateDeleteMakeModel_MakeSelectMake;
        private System.Windows.Forms.Label lblUpdateDeleteMakeModel_MakeMake;
        private System.Windows.Forms.Label lblUpdateDeleteMakeModel_SelectMake;
        private System.Windows.Forms.ComboBox cbUpdateDeleteMakeModel_ModelMake;
        private System.Windows.Forms.Label lblUpdateDeleteMakeModel_ModelSelectMake;
        private System.Windows.Forms.TextBox txtUpdateDeleteMakeModel_ModelModel;
        private System.Windows.Forms.TextBox txtUpdateDeleteMakeModel_ModelMake;
        private System.Windows.Forms.Label lblUpdateDeleteMakeModel_ModelModel;
        private System.Windows.Forms.Label lblUpdateDeleteMakeModel_ModelMake;
        private System.Windows.Forms.ComboBox cbUpdateDeleteMakeModel_ModelModel;
        private System.Windows.Forms.Label lblUpdateDeleteMakeModel_ModelSelectModel;
    }
}
